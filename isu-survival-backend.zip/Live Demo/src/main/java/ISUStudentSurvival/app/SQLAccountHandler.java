package ISUStudentSurvival.app;

import java.sql.*;
import java.util.List;
import ISUStudentSurvival.model.Account;

public class SQLAccountHandler extends DBCRUDHandler<Account>
{
    public SQLAccountHandler(DBConnection connection)
    {
        super(connection);
    }

    @Override
    public boolean create(Account account)
    {
        String sql = "INSERT INTO account (EMAIL, NAME, DEPARTMENT, YEARVALUE, PASSWORD, USERNAME, YEAR, ANONYMITY, NOTIFICATIONS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, account.getEmail());
            stmt.setString(2, account.getName());
            stmt.setString(3, account.getDepartment());
            stmt.setInt(4, account.getYearValue());
            stmt.setString(5, account.getPassword());
            stmt.setString(6, account.getUsername());
            stmt.setString(7, account.getYear());
            stmt.setInt(8, account.isAnonymity() ? 1 : 0);
            stmt.setInt(9, account.isNotifications() ? 1 : 0);

            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Account getById(int id)
    {
        String sql = "SELECT * FROM account WHERE accountid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next())
            {
                return mapRow(rs);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    private Account mapRow(ResultSet rs) throws SQLException
    {
        Account account = new Account(
                rs.getInt("accountid"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("password"),
                rs.getInt("yearvalue"),
                rs.getString("year"),
                rs.getString("username"),
                rs.getString("department")
        );
        account.setAnonymity(rs.getInt("anonymity") == 1);
        account.setNotifications(rs.getInt("notifications") == 1);
        return account;
    }

    @Override
    public List<Account> getAll()
    {
        String sql = "SELECT * FROM account";
        List<Account> accounts = new java.util.ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery())
        {
            while (rs.next())
            {
                accounts.add(mapRow(rs));
            }
            return accounts;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean update(Account account)
    {
        String sql = "UPDATE account SET "
                + "EMAIL = ?, "
                + "NAME = ?, "
                + "DEPARTMENT = ?, "
                + "YEARVALUE = ?, "
                + "PASSWORD = ?, "
                + "USERNAME = ?, "
                + "YEAR = ?, "
                + "ANONYMITY = ?, "
                + "NOTIFICATIONS = ? "
                + "WHERE ACCOUNTID = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, account.getEmail());
            stmt.setString(2, account.getName());
            stmt.setString(3, account.getDepartment());
            stmt.setInt(4, account.getYearValue());
            stmt.setString(5, account.getPassword());
            stmt.setString(6, account.getUsername());
            stmt.setString(7, account.getYear());
            stmt.setInt(8, account.isAnonymity() ? 1 : 0);
            stmt.setInt(9, account.isNotifications() ? 1 : 0);
            stmt.setInt(10, account.getAccountId());

            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id)
    {
        String sql = "DELETE FROM account WHERE accountid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }
}