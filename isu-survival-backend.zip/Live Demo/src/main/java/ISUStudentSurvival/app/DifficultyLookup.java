package ISUStudentSurvival.app;

import ISUStudentSurvival.model.Course;

public interface DifficultyLookup {
    double getDifficulty(Course course);
}
