package ISUStudentSurvival.app;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.model.FilterCourse;
import ISUStudentSurvival.model.Search;


/**
 * Handles all CRUD operations for the Course table.
 * Extends DBCRUDHandler to inherit connection handling and method structure.
 * Implements Search and FilterCourse from the class diagram.
 */
public class SQLCourseHandler extends DBCRUDHandler<Course> implements Search, FilterCourse {

    public SQLCourseHandler(DBConnection connection) {
        super(connection);
    }

    /**
     * Inserts a new Course into the database. COURSEID is assigned by the
     * Oracle sequence default on the column, so we omit it from the INSERT.
     */
    @Override
    public boolean create(Course course) {
        String sql = "INSERT INTO course (COURSENAME, COURSECODE, DEPARTMENT) VALUES (?, ?, ?)";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"courseid"})) {

            stmt.setString(1, course.getCourseName());
            stmt.setInt(2, course.getCourseCode());
            stmt.setString(3, course.getDepartment());

            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    course.setCourseId(keys.getInt(1));
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Course getById(int id) {
        String sql = "SELECT courseid, coursename, coursecode, department FROM course WHERE courseid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Course> getAll() {
        String sql = "SELECT courseid, coursename, coursecode, department FROM course";
        List<Course> courses = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                courses.add(mapRow(rs));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    @Override
    public boolean update(Course course) {
        String sql = "UPDATE course SET coursename = ?, coursecode = ?, department = ? WHERE courseid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, course.getCourseName());
            stmt.setInt(2, course.getCourseCode());
            stmt.setString(3, course.getDepartment());
            stmt.setInt(4, course.getCourseId());

            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM course WHERE courseid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Use case 3.1.6 — search by course name, course code, or department.
     */
    @Override
    public List<Course> search(String query) {
        if (query == null || query.isBlank()) {
            return getAll();
        }
        String sql = "SELECT courseid, coursename, coursecode, department FROM course "
                   + "WHERE LOWER(coursename) LIKE ? "
                   + "OR LOWER(department) LIKE ? "
                   + "OR TO_CHAR(coursecode) LIKE ?";
        List<Course> courses = new ArrayList<>();
        String like = "%" + query.toLowerCase() + "%";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, like);
            stmt.setString(2, like);
            stmt.setString(3, like);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    courses.add(mapRow(rs));
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    /**
     * Use case 3.1.17 — filter by course level. A level of 100 returns
     * courses whose code is in [100,199], 200 returns [200,299], etc.
     */
    @Override
    public List<Course> filterByCourseLevel(int level) {
        String sql = "SELECT courseid, coursename, coursecode, department FROM course "
                   + "WHERE coursecode >= ? AND coursecode < ?";
        List<Course> courses = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, level);
            stmt.setInt(2, level + 100);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    courses.add(mapRow(rs));
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    /**
     * Use case 3.1.10 — sort by rating. Stubbed: rating table not yet wired
     * in this iteration, so this returns the same list as getAll().
     */
    @Override
    public List<Course> filterByRating() {
        return getAll();
    }

    /**
     * Use case 3.1.15 — sort by difficulty. Stubbed for the same reason as
     * filterByRating.
     */
    @Override
    public List<Course> filterByDifficulty() {
        return getAll();
    }

    private Course mapRow(ResultSet rs) throws SQLException {
        Course course = new Course(
            rs.getString("coursename"),
            rs.getInt("coursecode"),
            rs.getString("department")
        );
        course.setCourseId(rs.getInt("courseid"));
        return course;
    }
}
