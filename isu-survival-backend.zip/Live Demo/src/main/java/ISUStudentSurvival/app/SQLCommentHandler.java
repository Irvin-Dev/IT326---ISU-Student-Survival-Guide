package ISUStudentSurvival.app;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ISUStudentSurvival.model.Comment;


/**
 * Handles all CRUD operations for the Comment table.
 * Extends DBCRUDHandler to inherit connection handling and method structure.
 */
public class SQLCommentHandler extends DBCRUDHandler<Comment>
{
    public SQLCommentHandler(DBConnection connection)
    {
        super(connection);
    }

    /**
     * Inserts a new Comment. COMMENTID is assigned by the Oracle sequence.
     * CREATEDAT defaults to CURRENT_TIMESTAMP at the column level.
     * Note: we don't request the auto-generated key here because COMMENT is
     * an Oracle reserved word, which makes the driver's auto-key metadata
     * lookup throw ORA-00931. The frontend re-fetches comments after a post.
     */
    @Override
    public boolean create(Comment comment)
    {
        String sql = "INSERT INTO commentinfo (COMMENTCONTENT, COURSEID, ACCOUNTID, PARENTCOMMENTID) VALUES (?, ?, ?, ?)";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, comment.getComment());
            stmt.setInt(2, comment.getCourseId());
            stmt.setInt(3, comment.getAccountId());
            if (comment.getParentCommentId() == null)
            {
                stmt.setNull(4, Types.NUMERIC);
            }
            else
            {
                stmt.setInt(4, comment.getParentCommentId());
            }

            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Comment getById(int id)
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid WHERE c.commentid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    return mapRow(rs);
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Comment> getAll()
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid";
        List<Comment> comments = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery())
        {
            while (rs.next())
            {
                comments.add(mapRow(rs));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return comments;
    }

    public List<Comment> getByCourseId(int courseId)
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid "
                   + "WHERE c.courseid = ? ORDER BY c.createdat ASC";
        List<Comment> comments = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    comments.add(mapRow(rs));
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return comments;
    }

    @Override
    public boolean update(Comment comment)
    {
        String sql = "UPDATE commentinfo SET COMMENTCONTENT = ?, UPDATEDAT = CURRENT_TIMESTAMP WHERE commentid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, comment.getComment());
            stmt.setInt(2, comment.getCommentId());

            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Deletes a comment and any replies that reference it via PARENTCOMMENTID.
     * Per use case 3.1.13: "any replies to that comment will be deleted too."
     */
    @Override
    public boolean delete(int id)
    {
        String deleteReplies = "DELETE FROM commentinfo WHERE parentcommentid = ?";
        String deleteSelf = "DELETE FROM commentinfo WHERE commentid = ?";

        try (Connection conn = open())
        {
            try (PreparedStatement stmt = conn.prepareStatement(deleteReplies))
            {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt = conn.prepareStatement(deleteSelf))
            {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    private Comment mapRow(ResultSet rs) throws SQLException
    {
        Comment c = new Comment();
        c.setCommentId(rs.getInt("commentid"));
        c.setComment(rs.getString("commentcontent"));
        c.setCourseId(rs.getInt("courseid"));
        c.setAccountId(rs.getInt("accountid"));
        int parent = rs.getInt("parentcommentid");
        c.setParentCommentId(rs.wasNull() ? null : parent);
        c.setCreatedAt(rs.getTimestamp("createdat"));
        c.setUpdatedAt(rs.getTimestamp("updatedat"));

        boolean anonymous = rs.getInt("anonymity") == 1;
        c.setAuthorUsername(anonymous ? null : rs.getString("username"));
        return c;
    }
}
