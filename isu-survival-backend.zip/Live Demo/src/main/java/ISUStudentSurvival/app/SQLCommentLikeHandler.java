package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SQLCommentLikeHandler
{
    private final DBConnection connection;
    private final SQLCommentHandler commentHandler;

    public SQLCommentLikeHandler(DBConnection connection, SQLCommentHandler commentHandler)
    {
        this.connection = connection;
        this.commentHandler = commentHandler;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /** Adds a like row + bumps the cached count atomically. */
    public boolean like(int commentId, int accountId)
    {
        String sql = "INSERT INTO comment_likes (COMMENT_ID, USER_ID) VALUES (?, ?)";
        Connection conn = null;
        try
        {
            conn = open();
            conn.setAutoCommit(false);

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setInt(1, commentId);
                stmt.setInt(2, accountId);
                stmt.executeUpdate();
            }
            commentHandler.incrementLikes(commentId, conn);

            conn.commit();
            return true;
        }
        catch (SQLException e)
        {
            if (conn != null)
            {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace();
            return false;
        }
        finally
        {
            if (conn != null)
            {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    public boolean unlike(int commentId, int accountId)
    {
        String sql = "DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?";
        Connection conn = null;
        try
        {
            conn = open();
            conn.setAutoCommit(false);

            int rows;
            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setInt(1, commentId);
                stmt.setInt(2, accountId);
                rows = stmt.executeUpdate();
            }
            if (rows == 0)
            {
                conn.rollback();
                return false;
            }
            commentHandler.decrementLikes(commentId, conn);

            conn.commit();
            return true;
        }
        catch (SQLException e)
        {
            if (conn != null)
            {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace();
            return false;
        }
        finally
        {
            if (conn != null)
            {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    public boolean hasLiked(int commentId, int accountId)
    {
        String sql = "SELECT 1 FROM comment_likes WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            stmt.setInt(2, accountId);
            try (ResultSet rs = stmt.executeQuery())
            {
                return rs.next();
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /** Returns the subset of commentIds the given user has liked. */
    public Set<Integer> getLikedSubset(int accountId, List<Integer> commentIds)
    {
        Set<Integer> liked = new HashSet<>();
        if (commentIds == null || commentIds.isEmpty()) return liked;

        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < commentIds.size(); i++)
        {
            placeholders.append(i == 0 ? "?" : ", ?");
        }
        String sql = "SELECT comment_id FROM comment_likes "
                   + "WHERE user_id = ? AND comment_id IN (" + placeholders + ")";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            for (int i = 0; i < commentIds.size(); i++)
            {
                stmt.setInt(i + 2, commentIds.get(i));
            }
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next()) liked.add(rs.getInt(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return liked;
    }
}
