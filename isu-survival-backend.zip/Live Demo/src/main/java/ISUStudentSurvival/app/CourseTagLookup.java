package ISUStudentSurvival.app;

import ISUStudentSurvival.model.ClassTag;
import java.util.List;

public interface CourseTagLookup {

    List<ClassTag> getAllCourseTagsById(int id);
    
}