package ISUStudentSurvival.app;

import java.util.List;

public interface CourseTagLookup {

    List<CourseTag> getAllCourseTagsById(int id);
    
}