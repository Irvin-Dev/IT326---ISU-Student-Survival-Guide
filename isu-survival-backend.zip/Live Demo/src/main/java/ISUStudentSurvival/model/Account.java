package ISUStudentSurvival.model;

public class Account {
    private int accountId;
    private String name;
    private String email;
    private String password;
    private int yearValue;
    private boolean anonymity;
    private boolean notifications;
    private String department;

    public Account() {}

    public Account(String email, String password, String name, int yearValue, boolean anonymity, boolean notifications, String department) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.yearValue = yearValue;
        this.anonymity = anonymity;
        this.notifications = notifications;
        this.department = department;
    }

    public Account(int accountId, String name, String email, String password, int yearValue, boolean anonymity, boolean notifications, String department) {
        this.accountId = accountId;
        this.name = name;
        this.email = email;
        this.password = password;
        this.yearValue = yearValue;
        this.anonymity = anonymity;
        this.notifications = notifications;
        this.department = department;
    }

    public int getAccountId() {
        return accountId;
    }

    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }
    public int getYearValue() {
        return yearValue;
    }
    public boolean isAnonymity() {
        return anonymity;
    }
    public boolean isNotifications() {
        return notifications;
    }
    public String getDepartment() {
        return department;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setYearValue(int yearValue) {
        this.yearValue = yearValue;
    }
    public void setAnonymity(boolean anonymity) {
        this.anonymity = anonymity;
    }
    public void setNotifications(boolean notifications) {
        this.notifications = notifications;
    }
    public void setDepartment(String department) {
        this.department = department;
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
    }
}