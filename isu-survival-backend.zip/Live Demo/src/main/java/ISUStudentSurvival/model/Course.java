package ISUStudentSurvival.model;

import java.util.ArrayList;
import java.util.List;

public class Course
{

    private int courseId;

    private String courseName;

    private int courseCode;

    private String department;

    private List<ClassTag> courseTagList = new ArrayList<>();

    private List<AddRatings> ratingList = new ArrayList<>();

    private List<Comment> commentList = new ArrayList<>();

    public Course() {}

    public Course(String courseName, Integer courseCode, String department)
    {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.department = department;
    }

    public String getCourseName()
    {
        return courseName;
    }

    public int getCourseId()
    {
        return courseId;
    }

    public int getCourseCode()
    {
        return courseCode;
    }

    public String getDepartment()
    {
        return department;
    }

    public List<ClassTag> getCourseTagList()
    {
        return courseTagList;
    }

    public List<AddRatings> getRatingList()
    {
        return ratingList;
    }

    public List<Comment> getCommentList()
    {
        return commentList;
    }

    public void setCourseName(String courseName)
    {
        this.courseName = courseName;
    }

    public void setCourseId(Integer courseId)
    {
        this.courseId = courseId;
    }

    public void setCourseCode(Integer courseCode)
    {
        this.courseCode = courseCode;
    }

    public void setDepartment(String department)
    {
        this.department = department;
    }

    public String toString()
    {
        return "||Course||\n" + "Course Name: " + courseName + "\nCourse ID: " + courseId + "\nCourse Code: " + courseCode + "\nDepartment: " + department;
    }

    public void updateTagList(ClassTag tag)
    {
        courseTagList.add(tag);
    }

    public void updateRatings(AddRatings rating)
    {
        ratingList.add(rating);
    }

    public void updateComments(Comment comment)
    {
        commentList.add(comment);
    }

    public int[] generateCourseDistribution()
    {
        int[] distribution = new int[5];
        for (AddRatings r : ratingList)
        {
            int v = r.getCourseRating();
            if (v >= 1 && v <= 5)
            {
                distribution[v - 1]++;
            }
        }
        return distribution;
    }
}
