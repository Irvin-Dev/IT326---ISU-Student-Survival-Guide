package ISUStudentSurvival.model;

public class ClassTag
{

    private int tagId;
    private String keyword;

    private Course course;

    public ClassTag() {}

    public ClassTag(String keyword, Course course)
    {
        this.keyword = keyword;
        this.course = course;
    }

    public int getTagId()
    {
        return tagId;
    }

    public String getKeyword()
    {
        return keyword;
    }

    public Course getCourse()
    {
        return course;
    }

    public void setKeyword(String keyword)
    {
        this.keyword = keyword;
    }

    public String toString()
    {
        return "Class Tag(s): " + keyword;
    }
}