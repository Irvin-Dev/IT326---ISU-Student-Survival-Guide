package ISUStudentSurvival.model;

import java.sql.Timestamp;

public class Comment
{

    private int commentId;
    private String comment;
    private int likes;
    private Integer parentCommentId;
    private int courseId;
    private int accountId;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private String authorUsername;


    private Account account;

    private Course course;

    public Comment() {}

    public Comment(String comment, Account account, Course course)
    {
        this.comment = comment;
        this.account = account;
        this.course = course;
        this.likes = 0;
    }

    //public int createComment() {

    //}

    public int getCommentId()
    {
        return commentId;
    }

    public String getComment()
    {
        return comment;
    }

    public int getLikes()
    {
        return likes;
    }

    public Integer getParentCommentId()
    {
        return parentCommentId;
    }

    public Account getAccount()
    {
        return account;
    }

    public Course getCourse()
    {
        return course;
    }

    public int getCourseId()
    {
        return courseId;
    }

    public int getAccountId()
    {
        return accountId;
    }

    public Timestamp getCreatedAt()
    {
        return createdAt;
    }

    public Timestamp getUpdatedAt()
    {
        return updatedAt;
    }

    public String getAuthorUsername()
    {
        return authorUsername;
    }

    public void setCommentId(int commentId)
    {
        this.commentId = commentId;
    }

    public void setComment(String comment)
    {
        this.comment = comment;
    }

    public void setLikes(int likes)
    {
        this.likes = likes;
    }

    public void setParentCommentId(Integer parentCommentId)
    {
        this.parentCommentId = parentCommentId;
    }

    public void setCourseId(int courseId)
    {
        this.courseId = courseId;
    }

    public void setAccountId(int accountId)
    {
        this.accountId = accountId;
    }

    public void setCreatedAt(Timestamp createdAt)
    {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(Timestamp updatedAt)
    {
        this.updatedAt = updatedAt;
    }

    public void setAuthorUsername(String authorUsername)
    {
        this.authorUsername = authorUsername;
    }

    public String toString()
    {
        return "Comment: " + comment;
    }

    public void addClassTag()
    {
    }
}