package ISUStudentSurvival.model;

public class Comment
{

    private int commentId;
    private String comment;
    private int likes;
    private Integer parentCommentId;


    private Account account;

    private Course course;

    public Comment() {}

    public Comment(String comment, Account account, Course course)
    {
        this.comment = comment;
        this.account = account;
        this.course = course;
        this.likes = 0;
    }

    public int getCommentId()
    {
        return commentId;
    }

    public String getComment()
    {
        return comment;
    }

    public int getLikes()
    {
        return likes;
    }

    public Integer getParentCommentId()
    {
        return parentCommentId;
    }

    public Account getAccount()
    {
        return account;
    }

    public Course getCourse()
    {
        return course;
    }

    public void setComment(String comment)
    {
        this.comment = comment;
    }

    public void setLikes(int likes)
    {
        this.likes = likes;
    }

    public void setParentCommentId(Integer parentCommentId)
    {
        this.parentCommentId = parentCommentId;
    }

    public String toString()
    {
        return "Comment: " + comment;
    }

    public void addClassTag()
    {
    }
}