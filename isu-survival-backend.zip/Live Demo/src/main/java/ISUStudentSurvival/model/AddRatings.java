package ISUStudentSurvival.model;

public class AddRatings
{

    private int ratingId;


    private int courseRating;


    private int difficultyRating;


    private Account account;

    private Course course;

    public AddRatings() {}

    public AddRatings(int courseRating, int difficultyRating, Account account, Course course)
    {
        this.courseRating = courseRating;
        this.difficultyRating = difficultyRating;
        this.account = account;
        this.course = course;
    }

    public int getRatingId()
    {
        return ratingId;
    }

    public int getCourseRating()
    {
        return courseRating;
    }

    public int getDifficultyRating()
    {
        return difficultyRating;
    }

    public Account getAccount()
    {
        return account;
    }

    public Course getCourse()
    {
        return course;
    }

    public void setCourseRating(int courseRating)
    {
        this.courseRating = courseRating;
    }

    public void setDifficultyRating(int difficultyRating)
    {
        this.difficultyRating = difficultyRating;
    }

    public String toString()
    {
        return "||Course Ratings||\n" + "Course Rating: " + courseRating + "\nDifficulty Rating: " + difficultyRating;
    }

    public void addRating(int rating)
    {
    }

    public void addDifficulty(int diffRating)
    {
    }
}