package ISUStudentSurvival.model;

import java.util.List;

public interface Search
{
    List<Course> search(String query);
}
