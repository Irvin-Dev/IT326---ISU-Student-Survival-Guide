package ISUStudentSurvival.model;

import java.util.List;

public interface FilterCourse
{
    List<Course> filterByRating();

    List<Course> filterByDifficulty();

    List<Course> filterByCourseLevel(int level);
}
