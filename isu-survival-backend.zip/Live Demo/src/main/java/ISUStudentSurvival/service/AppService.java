package ISUStudentSurvival.service;

import ISUStudentSurvival.SQLDBConnection;
import ISUStudentSurvival.app.SQLAccountHandler;
import ISUStudentSurvival.app.SQLCourseHandler;
import ISUStudentSurvival.app.SQLCommentHandler;
import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppService
{
    private final SQLAccountHandler accountHandler;
    private final SQLCourseHandler courseHandler;
    private final SQLCommentHandler commentHandler;

    @Autowired
    public AppService(SQLDBConnection connection)
    {
        this.accountHandler = new SQLAccountHandler(connection);
        this.courseHandler = new SQLCourseHandler(connection);
        this.commentHandler = new SQLCommentHandler(connection);
    }

    public Account login(String username, String password)
    {
        List<Account> accounts = accountHandler.getAll();
        if (accounts == null) return null;
        for (Account a : accounts)
        {
            if (a.getUsername().equals(username) && a.getPassword().equals(password))
            {
                return a;
            }
        }
        return null;
    }

    public Account createAccount(String email, String password, String name, int yearValue, String year, String username, String department)
    {
        Account account = new Account(email, password, name, yearValue, year, username, department);
        boolean success = accountHandler.create(account);
        if (!success) return null;
        return account;
    }

    public Account getAccountById(int id)
    {
        return accountHandler.getById(id);
    }

    public Account updateAccount(int id, String email, String name, String department, Integer yearValue, String year, String username, String password)
    {
        Account existing = accountHandler.getById(id);
        if (existing == null) return null;
        if (email != null) existing.setEmail(email);
        if (name != null) existing.setName(name);
        if (department != null) existing.setDepartment(department);
        if (yearValue != null) existing.setYearValue(yearValue);
        if (year != null) existing.setYear(year);
        if (username != null) existing.setUsername(username);
        if (password != null && !password.isBlank()) existing.setPassword(password);
        boolean success = accountHandler.update(existing);
        return success ? existing : null;
    }

    public boolean deleteAccount(int id)
    {
        return accountHandler.delete(id);
    }

    public Account updateAccountSettings(int id, Boolean anonymity, Boolean notifications)
    {
        Account existing = accountHandler.getById(id);
        if (existing == null) return null;
        if (anonymity != null) existing.setAnonymity(anonymity);
        if (notifications != null) existing.setNotifications(notifications);
        boolean success = accountHandler.update(existing);
        return success ? existing : null;
    }

    public List<Course> getAllCourses()
    {
        return courseHandler.getAll();
    }

    public Course getCourseById(int id)
    {
        return courseHandler.getById(id);
    }

    public Course createCourse(String courseName, int courseCode, String department)
    {
        Course course = new Course(courseName, courseCode, department);
        boolean success = courseHandler.create(course);
        if (!success) return null;
        return course;
    }

    public Course updateCourse(int id, String courseName, Integer courseCode, String department)
    {
        Course existing = courseHandler.getById(id);
        if (existing == null) return null;
        if (courseName != null) existing.setCourseName(courseName);
        if (courseCode != null) existing.setCourseCode(courseCode);
        if (department != null) existing.setDepartment(department);
        boolean success = courseHandler.update(existing);
        return success ? existing : null;
    }

    public boolean deleteCourse(int id)
    {
        return courseHandler.delete(id);
    }

    public List<Course> searchCourses(String query)
    {
        return courseHandler.search(query);
    }

    public List<Course> filterCoursesByLevel(int level)
    {
        return courseHandler.filterByCourseLevel(level);
    }

    public List<Comment> getCommentsByCourseId(int courseId)
    {
        return commentHandler.getByCourseId(courseId);
    }

    public Comment addComment(String content, int accountId, int courseId, Integer parentCommentId)
    {
        if (content == null || content.isBlank()) return null;
        Comment comment = new Comment();
        comment.setComment(content);
        comment.setAccountId(accountId);
        comment.setCourseId(courseId);
        comment.setParentCommentId(parentCommentId);
        boolean success = commentHandler.create(comment);
        if (!success) return null;
        return comment;
    }

    public Comment editComment(int commentId, int requesterId, String newContent)
    {
        if (newContent == null || newContent.isBlank()) return null;
        Comment existing = commentHandler.getById(commentId);
        if (existing == null) return null;
        if (existing.getAccountId() != requesterId) return null;
        existing.setComment(newContent);
        boolean success = commentHandler.update(existing);
        if (!success) return null;
        return commentHandler.getById(commentId);
    }

    public boolean deleteComment(int commentId, int requesterId)
    {
        Comment existing = commentHandler.getById(commentId);
        if (existing == null) return false;
        if (existing.getAccountId() != requesterId) return false;
        return commentHandler.delete(commentId);
    }
}
