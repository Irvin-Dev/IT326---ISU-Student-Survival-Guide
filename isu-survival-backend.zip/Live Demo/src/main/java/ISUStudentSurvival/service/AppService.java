package ISUStudentSurvival.service;

import ISUStudentSurvival.app.DBConnection;
import ISUStudentSurvival.SQLDBConnection;
import ISUStudentSurvival.app.SQLAccountHandler;
import ISUStudentSurvival.app.SQLCourseHandler;
import ISUStudentSurvival.app.SQLCommentHandler;
import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppService
{
    private final SQLAccountHandler accountHandler;
    private final SQLCourseHandler courseHandler;
    private final SQLCommentHandler commentHandler;

    @Autowired
    public AppService(SQLDBConnection connection)
    {
        this.accountHandler = new SQLAccountHandler(connection);
        this.courseHandler = new SQLCourseHandler(connection);
        this.commentHandler = new SQLCommentHandler(connection);
    }

    public Account login(String username, String password)
    {
        List<Account> accounts = accountHandler.getAll();
        if (accounts == null) return null;
        for (Account a : accounts)
        {
            if (a.getName().equals(username) && a.getPassword().equals(password))
            {
                return a;
            }
        }
        return null;
    }

    public Account createAccount(String email, String password, String name, int yearValue, boolean anonymity, boolean notifications, String department)
    {
        Account account = new Account(email, password, name, yearValue, anonymity, notifications, department);
        boolean success = accountHandler.create(account);
        if (!success) return null;
        return account;
    }

    public List<Course> getAllCourses()
    {
        return courseHandler.getAll();
    }

    public Course getCourseById(int id)
    {
        return courseHandler.getById(id);
    }

    public Course createCourse(String courseName, int courseCode, String department)
    {
        Course course = new Course(courseName, courseCode, department);
        boolean success = courseHandler.create(course);
        if (!success) return null;
        return course;
    }

    public List<Comment> getCommentsByCourseId(int courseId)
    {
        List<Comment> all = commentHandler.getAll();
        if (all == null) return List.of();
        return all.stream().filter(c -> c.getCourseId() == courseId).toList();
    }

    public boolean deleteComment(int commentId)
    {
        return commentHandler.delete(commentId);
    }

    public boolean updateComment(Comment comment)
    {
        return commentHandler.update(comment);
    }
}