package ISUStudentSurvival;

import ISUStudentSurvival.app.DBConnection;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Component
public class SQLDBConnection implements DBConnection {

    private static final String URL = "jdbc:oracle:thin:@10.110.10.90:1521:oracle";
    private static final String USER = "IT326S09";
    private static final String PASSWORD = "pink22";

    @Override
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}