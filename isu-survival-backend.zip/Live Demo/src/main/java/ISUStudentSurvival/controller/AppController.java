package ISUStudentSurvival.controller;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class AppController
{
    @Autowired
    private AppService appService;

    @PostMapping("/account/login")
    public ResponseEntity<Account> login(@RequestParam String username, @RequestParam String password)
    {
        Account account = appService.login(username, password);
        if (account == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(account);
    }

    @PostMapping("/account/create")
    public ResponseEntity<Account> createAccount(
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String name,
            @RequestParam(defaultValue = "1") int yearValue,
            @RequestParam(defaultValue = "") String year,
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String department)
    {
        Account account = appService.createAccount(email, password, name, yearValue, year, username, department);
        if (account == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(account);
    }

    @PutMapping("/account/{id}")
    public ResponseEntity<Account> updateAccount(
            @PathVariable int id,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) Integer yearValue,
            @RequestParam(required = false) String year,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String password)
    {
        Account account = appService.updateAccount(id, email, name, department, yearValue, year, username, password);
        if (account == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(account);
    }

    @DeleteMapping("/account/{id}")
    public ResponseEntity<Void> deleteAccount(@PathVariable int id)
    {
        boolean success = appService.deleteAccount(id);
        if (!success) return ResponseEntity.status(400).build();
        return ResponseEntity.ok().build();
    }

    @PutMapping("/account/{id}/settings")
    public ResponseEntity<Account> updateAccountSettings(
            @PathVariable int id,
            @RequestParam(required = false) Boolean anonymity,
            @RequestParam(required = false) Boolean notifications)
    {
        Account account = appService.updateAccountSettings(id, anonymity, notifications);
        if (account == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(account);
    }

    @GetMapping("/courses")
    public List<Course> getAllCourses()
    {
        return appService.getAllCourses();
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<Course> getCourse(@PathVariable int id)
    {
        Course course = appService.getCourseById(id);
        if (course == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(course);
    }

    @GetMapping("/courses/search")
    public List<Course> searchCourses(@RequestParam(defaultValue = "") String q)
    {
        return appService.searchCourses(q);
    }

    @GetMapping("/courses/level/{level}")
    public List<Course> filterCoursesByLevel(@PathVariable int level)
    {
        return appService.filterCoursesByLevel(level);
    }

    @PostMapping("/course/create")
    public ResponseEntity<Course> createCourse(
            @RequestParam String courseName,
            @RequestParam int courseCode,
            @RequestParam String department)
    {
        Course course = appService.createCourse(courseName, courseCode, department);
        if (course == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(course);
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<Course> updateCourse(
            @PathVariable int id,
            @RequestParam(required = false) String courseName,
            @RequestParam(required = false) Integer courseCode,
            @RequestParam(required = false) String department)
    {
        Course course = appService.updateCourse(id, courseName, courseCode, department);
        if (course == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(course);
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable int id)
    {
        boolean success = appService.deleteCourse(id);
        if (!success) return ResponseEntity.status(400).build();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/comments/{courseId}")
    public List<Comment> getComments(@PathVariable int courseId)
    {
        return appService.getCommentsByCourseId(courseId);
    }

    @PostMapping("/comment/create")
    public ResponseEntity<Comment> createComment(
            @RequestParam String comment,
            @RequestParam int accountId,
            @RequestParam int courseId,
            @RequestParam(required = false) Integer parentCommentId)
    {
        Comment created = appService.addComment(comment, accountId, courseId, parentCommentId);
        if (created == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(created);
    }

    @PutMapping("/comment/{id}")
    public ResponseEntity<Comment> updateComment(
            @PathVariable int id,
            @RequestParam String comment,
            @RequestParam int accountId)
    {
        Comment updated = appService.editComment(id, accountId, comment);
        if (updated == null) return ResponseEntity.status(403).build();
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/comment/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable int id, @RequestParam int accountId)
    {
        boolean success = appService.deleteComment(id, accountId);
        if (!success) return ResponseEntity.status(403).build();
        return ResponseEntity.ok().build();
    }
}
