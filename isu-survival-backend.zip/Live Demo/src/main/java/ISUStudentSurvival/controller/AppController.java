package ISUStudentSurvival.controller;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class AppController {

    @Autowired
    private AppService appService;

    @PostMapping("/account/login")
    public ResponseEntity<Account> login(@RequestParam String username, @RequestParam String password) {
        Account account = appService.login(username, password);
        if (account == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(account);
    }

    @PostMapping("/account/create")
    public ResponseEntity<Account> createAccount(
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String name,
            @RequestParam(defaultValue = "1") int yearValue,
            @RequestParam(defaultValue = "false") boolean anonymity,
            @RequestParam(defaultValue = "false") boolean notifications,
            @RequestParam(defaultValue = "") String department) {
        Account account = appService.createAccount(email, password, name, yearValue, anonymity, notifications, department);
        if (account == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(account);
    }

    @GetMapping("/courses")
    public List<Course> getAllCourses() {
        return appService.getAllCourses();
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<Course> getCourse(@PathVariable int id) {
        Course course = appService.getCourseById(id);
        if (course == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(course);
    }

    @PostMapping("/course/create")
    public ResponseEntity<Course> createCourse(
            @RequestParam String courseName,
            @RequestParam int courseCode,
            @RequestParam String department) {
        Course course = appService.createCourse(courseName, courseCode, department);
        if (course == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(course);
    }

    @GetMapping("/comments/{courseId}")
    public List<Comment> getComments(@PathVariable int courseId) {
        return appService.getCommentsByCourseId(courseId);
    }

    @PostMapping("/comment/create")
    public ResponseEntity<Comment> createComment(
            @RequestParam int courseId,
            @RequestParam int accountId,
            @RequestParam String comment,
            @RequestParam(defaultValue = "0") double courseRating,
            @RequestParam(defaultValue = "0") double difficultyRating) {
        Comment c = appService.createComment(courseId, accountId, comment, courseRating, difficultyRating);
        if (c == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(c);
    }

    @DeleteMapping("/comment/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable int id) {
        boolean success = appService.deleteComment(id);
        if (!success) return ResponseEntity.status(400).build();
        return ResponseEntity.ok().build();
    }
}