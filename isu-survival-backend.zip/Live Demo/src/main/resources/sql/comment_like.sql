CREATE TABLE comment_like (
    accountid       NUMBER          NOT NULL,
    commentid       NUMBER          NOT NULL,
    createdat       TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,

    CONSTRAINT pk_comment_like
        PRIMARY KEY (accountid, commentid),

    CONSTRAINT fk_comment_like_account
        FOREIGN KEY (accountid)
        REFERENCES account (accountid)
        ON DELETE CASCADE,

    CONSTRAINT fk_comment_like_comment
        FOREIGN KEY (commentid)
        REFERENCES commentinfo (commentid)
        ON DELETE CASCADE
);

CREATE INDEX idx_comment_like_commentid
    ON comment_like (commentid);

CREATE INDEX idx_comment_like_accountid
    ON comment_like (accountid);
