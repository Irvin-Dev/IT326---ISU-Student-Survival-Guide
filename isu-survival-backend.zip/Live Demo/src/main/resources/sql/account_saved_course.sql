CREATE TABLE account_saved_course (
    accountid       NUMBER          NOT NULL,
    courseid        NUMBER          NOT NULL,
    savedat         TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,

    CONSTRAINT pk_account_saved_course
        PRIMARY KEY (accountid, courseid),

    CONSTRAINT fk_asc_account
        FOREIGN KEY (accountid)
        REFERENCES account (accountid)
        ON DELETE CASCADE,

    CONSTRAINT fk_asc_course
        FOREIGN KEY (courseid)
        REFERENCES course (courseid)
        ON DELETE CASCADE
);

CREATE INDEX idx_asc_accountid
    ON account_saved_course (accountid);

CREATE INDEX idx_asc_courseid
    ON account_saved_course (courseid);
