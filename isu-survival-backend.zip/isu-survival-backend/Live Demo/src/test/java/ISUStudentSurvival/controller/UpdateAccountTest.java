package ISUStudentSurvival.controller;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.service.AppService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
/*
        *By Julia Everett
        * Basis Path Testing for updateAccount endpoint:
        * 1. Account does NOT exist → return 404
        * 2. No fields provided → return unchanged account
        * 3. Fields provided → update success
        * 4. Fields provided → update fails → return 404
        
 */
public class UpdateAccountTest {

    private AppService service;
    private AppController controller;

    @BeforeEach
    void setUp() {
        service = mock(AppService.class);
        controller = new AppController();
        controller.setAppService(service); // inject mock
    }

    // Basis Path 1: Account does NOT exist → return 404
    @Test
    void testUpdateAccount_NotFound() {
        when(service.updateAccount(99, null, null, null, null, null, null, null))
                .thenReturn(null);

        ResponseEntity<Account> res = controller.updateAccount(
                99, null, null, null, null, null, null, null);

        assertEquals(404, res.getStatusCodeValue());
    }

    // Basis Path 2: No fields provided → return unchanged account
    @Test
    void testUpdateAccount_NoFieldsProvided() {
        Account existing = new Account();
        existing.setAccountId(1);

        when(service.updateAccount(1, null, null, null, null, null, null, null))
                .thenReturn(existing);

        ResponseEntity<Account> res = controller.updateAccount(
                1, null, null, null, null, null, null, null);

        assertEquals(200, res.getStatusCodeValue());
        assertEquals(existing, res.getBody());
    }

    // Basis Path 3: Fields provided → update success
    @Test
    void testUpdateAccount_SuccessfulUpdate() {
        Account updated = new Account();
        updated.setAccountId(1);
        updated.setName("New Name");

        when(service.updateAccount(1, null, "New Name", null, null, null, null, null))
                .thenReturn(updated);

        ResponseEntity<Account> res = controller.updateAccount(
                1, null, "New Name", null, null, null, null, null);

        assertEquals(200, res.getStatusCodeValue());
        assertEquals("New Name", res.getBody().getName());
    }

    // Basis Path 4: Fields provided → update fails → return 404
    @Test
    void testUpdateAccount_UpdateFails() {
        when(service.updateAccount(1, null, "Bad Name", null, null, null, null, null))
                .thenReturn(null);

        ResponseEntity<Account> res = controller.updateAccount(
                1, null, "Bad Name", null, null, null, null, null);

        assertEquals(404, res.getStatusCodeValue());
    }
}
