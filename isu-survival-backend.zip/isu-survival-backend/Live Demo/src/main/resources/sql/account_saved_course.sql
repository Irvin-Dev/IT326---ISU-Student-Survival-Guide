-- =====================================================================
-- ACCOUNT_SAVED_COURSE join table
-- Use cases 3.1.19 (Save a Course) and 3.1.20 (Remove from Saved List).
--
-- One row per (account, course) save. Composite PK prevents duplicate
-- saves. Both FKs cascade so when an account or course is deleted,
-- its saved-course rows go with it (no orphans, no FK errors).
-- =====================================================================

CREATE TABLE account_saved_course (
    accountid       NUMBER          NOT NULL,
    courseid        NUMBER          NOT NULL,
    savedat         TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,

    CONSTRAINT pk_account_saved_course
        PRIMARY KEY (accountid, courseid),

    CONSTRAINT fk_asc_account
        FOREIGN KEY (accountid)
        REFERENCES account (accountid)
        ON DELETE CASCADE,

    CONSTRAINT fk_asc_course
        FOREIGN KEY (courseid)
        REFERENCES course (courseid)
        ON DELETE CASCADE
);

-- Speeds up "list everything this user saved" — the most common query.
CREATE INDEX idx_asc_accountid
    ON account_saved_course (accountid);

-- Speeds up "did this user save course X" lookups used to flag bookmarks.
CREATE INDEX idx_asc_courseid
    ON account_saved_course (courseid);
