-- =====================================================================
-- COMMENT_LIKE join table
-- Use case 3.1.7 (Like a comment) and 3.1.11 (Sort comments by likes)
--
-- One row per (account, comment) like. Composite PK prevents a user
-- from liking the same comment twice. FKs cascade on delete so when
-- an account or comment is removed, its likes go with it.
-- =====================================================================

CREATE TABLE comment_like (
    accountid       NUMBER          NOT NULL,
    commentid       NUMBER          NOT NULL,
    createdat       TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,

    CONSTRAINT pk_comment_like
        PRIMARY KEY (accountid, commentid),

    CONSTRAINT fk_comment_like_account
        FOREIGN KEY (accountid)
        REFERENCES account (accountid)
        ON DELETE CASCADE,

    CONSTRAINT fk_comment_like_comment
        FOREIGN KEY (commentid)
        REFERENCES commentinfo (commentid)
        ON DELETE CASCADE
);

-- Speeds up "how many likes does comment X have" and the
-- ORDER BY likes_count queries used by 3.1.11.
CREATE INDEX idx_comment_like_commentid
    ON comment_like (commentid);

-- Speeds up "what has this user liked" lookups used to mark
-- a comment as already-liked in the UI.
CREATE INDEX idx_comment_like_accountid
    ON comment_like (accountid);
