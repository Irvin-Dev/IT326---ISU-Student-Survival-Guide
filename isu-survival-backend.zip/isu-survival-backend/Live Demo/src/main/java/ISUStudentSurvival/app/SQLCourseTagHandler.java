package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ISUStudentSurvival.model.ClassTag;

/**
 * Handler for the COURSETAG join table (courseid, commentid, coursetagnameid).
 * Each row represents "this comment applied this tag to this course."
 * Use cases: 3.1.18 (Add Course Tags), and powers tag-display on comments.
 */
public class SQLCourseTagHandler
{
    private final DBConnection connection;

    public SQLCourseTagHandler(DBConnection connection)
    {
        this.connection = connection;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /**
     * Inserts a single (course, comment, tag-name) row. Called inside the
     * comment-create transaction so it shares a connection with the others.
     */
    public boolean addTag(int courseId, int commentId, int tagNameId, Connection conn) throws SQLException
    {
        String sql = "INSERT INTO coursetag (COURSEID, COMMENTID, COURSETAGNAMEID) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            stmt.setInt(2, commentId);
            stmt.setInt(3, tagNameId);
            return stmt.executeUpdate() == 1;
        }
    }

    /**
     * Returns the tag-name objects (id + keyword) attached to a single
     * comment. Used by the frontend to render tag chips on each comment.
     */
    public List<ClassTag> getTagsForComment(int commentId)
    {
        String sql = "SELECT n.coursetagnameid, n.coursetagname "
                   + "FROM coursetag t "
                   + "JOIN coursetagname n ON t.coursetagnameid = n.coursetagnameid "
                   + "WHERE t.commentid = ? "
                   + "ORDER BY n.coursetagname";
        List<ClassTag> tags = new ArrayList<>();
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    ClassTag tag = new ClassTag();
                    tag.setTagId(rs.getInt("coursetagnameid"));
                    tag.setKeyword(rs.getString("coursetagname"));
                    tags.add(tag);
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return tags;
    }
}
