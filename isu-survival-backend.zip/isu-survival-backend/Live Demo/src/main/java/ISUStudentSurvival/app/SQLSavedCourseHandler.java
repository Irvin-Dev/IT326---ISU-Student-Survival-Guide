package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import ISUStudentSurvival.model.Course;

/**
 * Handler for ACCOUNT_SAVED_COURSE (accountid, courseid).
 * Use cases 3.1.19 (Save a Course) and 3.1.20 (Remove from Saved List).
 * Source of truth for "which courses has this user bookmarked."
 */
public class SQLSavedCourseHandler
{
    private final DBConnection connection;

    public SQLSavedCourseHandler(DBConnection connection)
    {
        this.connection = connection;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /**
     * Saves a course for a user. Returns false if the user already has
     * that course saved (composite PK rejects the duplicate INSERT) —
     * the controller maps that to a 409.
     */
    public boolean save(int accountId, int courseId)
    {
        String sql = "INSERT INTO account_saved_course (ACCOUNTID, COURSEID) VALUES (?, ?)";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            stmt.setInt(2, courseId);
            return stmt.executeUpdate() == 1;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Removes a saved-course row. Returns false if the row didn't exist
     * (user hadn't saved that course) so the controller can return 404.
     */
    public boolean unsave(int accountId, int courseId)
    {
        String sql = "DELETE FROM account_saved_course WHERE accountid = ? AND courseid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            stmt.setInt(2, courseId);
            return stmt.executeUpdate() == 1;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Returns the full course rows the user has saved, joined to COURSE
     * so the frontend gets name/code/department in one round-trip.
     * Ordered by save time, newest first.
     */
    public List<Course> getSavedCourses(int accountId)
    {
        String sql = "SELECT c.courseid, c.coursename, c.coursecode, c.department "
                   + "FROM account_saved_course s "
                   + "JOIN course c ON s.courseid = c.courseid "
                   + "WHERE s.accountid = ? "
                   + "ORDER BY s.savedat DESC";
        List<Course> courses = new ArrayList<>();
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    Course c = new Course(
                            rs.getString("coursename"),
                            rs.getInt("coursecode"),
                            rs.getString("department"));
                    c.setCourseId(rs.getInt("courseid"));
                    courses.add(c);
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return courses;
    }

    /**
     * Returns the set of course ids this user has saved. Used to mark
     * the bookmark icon on every card in one query (instead of N).
     */
    public Set<Integer> getSavedCourseIds(int accountId)
    {
        Set<Integer> ids = new HashSet<>();
        String sql = "SELECT courseid FROM account_saved_course WHERE accountid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next()) ids.add(rs.getInt(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return ids;
    }
}
