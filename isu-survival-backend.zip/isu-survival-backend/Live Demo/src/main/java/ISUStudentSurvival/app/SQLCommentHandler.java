package ISUStudentSurvival.app;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ISUStudentSurvival.model.Comment;


/**
 * Handles all CRUD operations for the Comment table.
 * Extends DBCRUDHandler to inherit connection handling and method structure.
 */
public class SQLCommentHandler extends DBCRUDHandler<Comment>
{
    public SQLCommentHandler(DBConnection connection)
    {
        super(connection);
    }

    /**
     * Inserts a new Comment. COMMENTID is assigned by the Oracle sequence.
     * CREATEDAT defaults to CURRENT_TIMESTAMP at the column level.
     * On success the generated commentid is written back into the Comment
     * via setCommentId(), so callers can use it to insert rating/difficulty/
     * tag rows that share the same commentid in the same transaction.
     */
    @Override
    public boolean create(Comment comment)
    {
        return createOnConnection(comment, null);
    }

    /**
     * Transaction-aware variant of create() — when the caller is doing a
     * multi-table atomic insert (comment + rating + difficulty + tags), it
     * passes in its own connection so everything commits or rolls back
     * together. If conn is null we open a fresh autocommit connection.
     */
    public boolean createOnConnection(Comment comment, Connection conn)
    {
        String sql = "INSERT INTO commentinfo (COMMENTCONTENT, COURSEID, ACCOUNTID, PARENTCOMMENTID) VALUES (?, ?, ?, ?)";
        boolean ownConnection = (conn == null);
        Connection c = null;
        PreparedStatement stmt = null;
        try
        {
            c = ownConnection ? open() : conn;
            stmt = c.prepareStatement(sql, new String[]{"commentid"});

            stmt.setString(1, comment.getComment());
            stmt.setInt(2, comment.getCourseId());
            stmt.setInt(3, comment.getAccountId());
            if (comment.getParentCommentId() == null)
            {
                stmt.setNull(4, Types.NUMERIC);
            }
            else
            {
                stmt.setInt(4, comment.getParentCommentId());
            }

            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys())
            {
                if (keys.next())
                {
                    comment.setCommentId(keys.getInt(1));
                }
            }
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
        finally
        {
            try { if (stmt != null) stmt.close(); } catch (SQLException ignored) {}
            if (ownConnection && c != null)
            {
                try { c.close(); } catch (SQLException ignored) {}
            }
        }
    }

    @Override
    public Comment getById(int id)
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, c.commentlike, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid WHERE c.commentid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    return mapRow(rs);
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Comment> getAll()
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, c.commentlike, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid";
        List<Comment> comments = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery())
        {
            while (rs.next())
            {
                comments.add(mapRow(rs));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return comments;
    }

    public List<Comment> getByCourseId(int courseId)
    {
        String sql = "SELECT c.commentid, c.commentcontent, c.courseid, c.accountid, c.parentcommentid, c.createdat, c.updatedat, c.commentlike, "
                   + "a.username, a.anonymity FROM commentinfo c LEFT JOIN account a ON c.accountid = a.accountid "
                   + "WHERE c.courseid = ? ORDER BY c.createdat ASC";
        List<Comment> comments = new ArrayList<>();

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    comments.add(mapRow(rs));
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return comments;
    }

    @Override
    public boolean update(Comment comment)
    {
        String sql = "UPDATE commentinfo SET COMMENTCONTENT = ?, UPDATEDAT = CURRENT_TIMESTAMP WHERE commentid = ?";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setString(1, comment.getComment());
            stmt.setInt(2, comment.getCommentId());

            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Deletes a comment and any replies that reference it via PARENTCOMMENTID.
     * Per use case 3.1.13: "any replies to that comment will be deleted too."
     */
    @Override
    public boolean delete(int id)
    {
        String deleteReplies = "DELETE FROM commentinfo WHERE parentcommentid = ?";
        String deleteSelf = "DELETE FROM commentinfo WHERE commentid = ?";

        try (Connection conn = open())
        {
            try (PreparedStatement stmt = conn.prepareStatement(deleteReplies))
            {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt = conn.prepareStatement(deleteSelf))
            {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    private Comment mapRow(ResultSet rs) throws SQLException
    {
        Comment c = new Comment();
        c.setCommentId(rs.getInt("commentid"));
        c.setComment(rs.getString("commentcontent"));
        c.setCourseId(rs.getInt("courseid"));
        c.setAccountId(rs.getInt("accountid"));
        int parent = rs.getInt("parentcommentid");
        c.setParentCommentId(rs.wasNull() ? null : parent);
        c.setCreatedAt(rs.getTimestamp("createdat"));
        c.setUpdatedAt(rs.getTimestamp("updatedat"));

        int likes = rs.getInt("commentlike");
        c.setLikes(rs.wasNull() ? 0 : likes);

        boolean anonymous = rs.getInt("anonymity") == 1;
        c.setAuthorUsername(anonymous ? null : rs.getString("username"));
        return c;
    }

    /**
     * Increments commentlike on COMMENTINFO. Used by SQLCommentLikeHandler
     * after a successful INSERT into the join table so the cached count
     * stays in sync with the source-of-truth row count.
     */
    public boolean incrementLikes(int commentId, Connection conn) throws SQLException
    {
        String sql = "UPDATE commentinfo SET commentlike = NVL(commentlike, 0) + 1 WHERE commentid = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            return stmt.executeUpdate() == 1;
        }
    }

    /**
     * Decrements commentlike on COMMENTINFO. The GREATEST(...) guard prevents
     * the count going negative if rows ever drift out of sync.
     */
    public boolean decrementLikes(int commentId, Connection conn) throws SQLException
    {
        String sql = "UPDATE commentinfo SET commentlike = GREATEST(NVL(commentlike, 0) - 1, 0) WHERE commentid = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            return stmt.executeUpdate() == 1;
        }
    }
}
