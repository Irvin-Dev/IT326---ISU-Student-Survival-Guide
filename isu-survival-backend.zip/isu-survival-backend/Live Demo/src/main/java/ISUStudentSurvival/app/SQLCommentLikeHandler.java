package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Handler for COMMENT_LIKES (comment_id, user_id).
 * Source of truth for "who liked what." The cached count lives on
 * commentinfo.commentlike and is kept in sync via SQLCommentHandler's
 * incrementLikes / decrementLikes inside the same transaction.
 *
 * Use cases: 3.1.7 (Like a comment), 3.1.11 (Sort by Likes).
 */
public class SQLCommentLikeHandler
{
    private final DBConnection connection;
    private final SQLCommentHandler commentHandler;

    public SQLCommentLikeHandler(DBConnection connection, SQLCommentHandler commentHandler)
    {
        this.connection = connection;
        this.commentHandler = commentHandler;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /**
     * Adds a like row + bumps the cached count atomically. Returns false
     * if the user has already liked the comment (composite PK rejects
     * the duplicate INSERT) — the controller maps that to a 409.
     */
    public boolean like(int commentId, int accountId)
    {
        String sql = "INSERT INTO comment_likes (COMMENT_ID, USER_ID) VALUES (?, ?)";
        Connection conn = null;
        try
        {
            conn = open();
            conn.setAutoCommit(false);

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setInt(1, commentId);
                stmt.setInt(2, accountId);
                stmt.executeUpdate();
            }
            commentHandler.incrementLikes(commentId, conn);

            conn.commit();
            return true;
        }
        catch (SQLException e)
        {
            if (conn != null)
            {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace();
            return false;
        }
        finally
        {
            if (conn != null)
            {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    /**
     * Removes a like row + decrements the cached count atomically.
     * Returns false if the row didn't exist (user hadn't liked it).
     */
    public boolean unlike(int commentId, int accountId)
    {
        String sql = "DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?";
        Connection conn = null;
        try
        {
            conn = open();
            conn.setAutoCommit(false);

            int rows;
            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setInt(1, commentId);
                stmt.setInt(2, accountId);
                rows = stmt.executeUpdate();
            }
            if (rows == 0)
            {
                conn.rollback();
                return false;
            }
            commentHandler.decrementLikes(commentId, conn);

            conn.commit();
            return true;
        }
        catch (SQLException e)
        {
            if (conn != null)
            {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace();
            return false;
        }
        finally
        {
            if (conn != null)
            {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    /**
     * Returns true if a given user has liked a given comment.
     * Used by the frontend to render the heart filled vs. hollow.
     */
    public boolean hasLiked(int commentId, int accountId)
    {
        String sql = "SELECT 1 FROM comment_likes WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            stmt.setInt(2, accountId);
            try (ResultSet rs = stmt.executeQuery())
            {
                return rs.next();
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Bulk version — given a user id and a list of comment ids,
     * returns the subset that this user has liked. Used to mark up
     * a whole comments-for-course payload in one query instead of N.
     */
    public Set<Integer> getLikedSubset(int accountId, List<Integer> commentIds)
    {
        Set<Integer> liked = new HashSet<>();
        if (commentIds == null || commentIds.isEmpty()) return liked;

        // Build (?, ?, ?, ...) placeholder list.
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < commentIds.size(); i++)
        {
            placeholders.append(i == 0 ? "?" : ", ?");
        }
        String sql = "SELECT comment_id FROM comment_likes "
                   + "WHERE user_id = ? AND comment_id IN (" + placeholders + ")";

        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, accountId);
            for (int i = 0; i < commentIds.size(); i++)
            {
                stmt.setInt(i + 2, commentIds.get(i));
            }
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next()) liked.add(rs.getInt(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return liked;
    }
}
