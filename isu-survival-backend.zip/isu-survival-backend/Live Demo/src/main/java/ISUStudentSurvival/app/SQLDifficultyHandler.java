package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Handler for DIFFICULTY (courseid, commentid, difficultynumber).
 * Each comment can carry an optional difficulty rating. Use cases:
 *   3.1.15 Sort by Difficulty
 *   (Display: average difficulty on course page)
 */
public class SQLDifficultyHandler
{
    private final DBConnection connection;

    public SQLDifficultyHandler(DBConnection connection)
    {
        this.connection = connection;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /**
     * Inserts a difficulty row sharing the comment's commentid. Caller's
     * connection so it commits with the comment.
     */
    public boolean addDifficulty(int courseId, int commentId, Integer difficultyNumber, Connection conn) throws SQLException
    {
        String sql = "INSERT INTO difficulty (COURSEID, COMMENTID, DIFFICULTYNUMBER) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            stmt.setInt(2, commentId);
            if (difficultyNumber == null) stmt.setNull(3, Types.NUMERIC);
            else stmt.setInt(3, difficultyNumber);
            return stmt.executeUpdate() == 1;
        }
    }

    public Integer getDifficultyForComment(int commentId)
    {
        String sql = "SELECT difficultynumber FROM difficulty WHERE commentid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    int v = rs.getInt(1);
                    return rs.wasNull() ? null : v;
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Average difficulty for a course. NULL difficulty rows are excluded
     * automatically by AVG(). Returns null when no difficulty has ever
     * been recorded so the UI can render a dash.
     */
    public Double getAverageForCourse(int courseId)
    {
        String sql = "SELECT AVG(difficultynumber) FROM difficulty WHERE courseid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    double v = rs.getDouble(1);
                    return rs.wasNull() ? null : v;
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
