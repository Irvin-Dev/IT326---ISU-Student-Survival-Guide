package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ISUStudentSurvival.model.ClassTag;

/**
 * Read-only-ish handler for the COURSETAGNAME lookup table.
 * The frontend calls getAll() to populate the tag-picker chips.
 * Use case: 3.1.18 (Add Course Tags).
 */
public class SQLCourseTagNameHandler extends DBCRUDHandler<ClassTag>
{
    public SQLCourseTagNameHandler(DBConnection connection)
    {
        super(connection);
    }

    @Override
    public boolean create(ClassTag tag)
    {
        String sql = "INSERT INTO coursetagname (COURSETAGNAME) VALUES (?)";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"coursetagnameid"}))
        {
            stmt.setString(1, tag.getKeyword());
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys())
            {
                if (keys.next())
                {
                    tag.setTagId(keys.getInt(1));
                }
            }
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public ClassTag getById(int id)
    {
        String sql = "SELECT coursetagnameid, coursetagname FROM coursetagname WHERE coursetagnameid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next()) return mapRow(rs);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ClassTag> getAll()
    {
        String sql = "SELECT coursetagnameid, coursetagname FROM coursetagname ORDER BY coursetagname";
        List<ClassTag> tags = new ArrayList<>();
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery())
        {
            while (rs.next()) tags.add(mapRow(rs));
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return tags;
    }

    @Override
    public boolean update(ClassTag tag)
    {
        // Tag names are essentially immutable enums; no admin UI for this.
        return false;
    }

    @Override
    public boolean delete(int id)
    {
        String sql = "DELETE FROM coursetagname WHERE coursetagnameid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    private ClassTag mapRow(ResultSet rs) throws SQLException
    {
        ClassTag tag = new ClassTag();
        tag.setTagId(rs.getInt("coursetagnameid"));
        tag.setKeyword(rs.getString("coursetagname"));
        return tag;
    }
}
