package ISUStudentSurvival.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Handler for RATING (courseid, commentid, ratingvalue).
 * Each comment can carry one rating row. Use cases:
 *   3.1.5  Rate a Course
 *   3.1.10 Sort by Rating
 *   3.1.24 Generate Course Rating distribution
 */
public class SQLRatingHandler
{
    private final DBConnection connection;

    public SQLRatingHandler(DBConnection connection)
    {
        this.connection = connection;
    }

    private Connection open() throws SQLException
    {
        return connection.getConnection();
    }

    /**
     * Inserts a rating row tied to a freshly-created comment. Runs on the
     * caller's connection so it commits with the comment.
     */
    public boolean addRating(int courseId, int commentId, int ratingValue, Connection conn) throws SQLException
    {
        String sql = "INSERT INTO rating (COURSEID, COMMENTID, RATINGVALUE) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            stmt.setInt(2, commentId);
            stmt.setInt(3, ratingValue);
            return stmt.executeUpdate() == 1;
        }
    }

    /**
     * Returns the rating value for a single comment (or null if none).
     * Used to render the star count on each comment in the review list.
     */
    public Integer getRatingForComment(int commentId)
    {
        String sql = "SELECT ratingvalue FROM rating WHERE commentid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, commentId);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    int v = rs.getInt(1);
                    return rs.wasNull() ? null : v;
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Average rating across all rows for a course. Returns null if no
     * one has rated yet so the UI can show a dash instead of "0.0".
     */
    public Double getAverageForCourse(int courseId)
    {
        String sql = "SELECT AVG(ratingvalue) FROM rating WHERE courseid = ?";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    double v = rs.getDouble(1);
                    return rs.wasNull() ? null : v;
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 3.1.24 — distribution of star counts. Returns an ordered map
     * 1 -> count, 2 -> count, ... 5 -> count. Slots with no votes
     * are present as 0 so the bar chart on the frontend always
     * renders the same five bars.
     */
    public Map<Integer, Integer> getDistributionForCourse(int courseId)
    {
        Map<Integer, Integer> dist = new LinkedHashMap<>();
        for (int i = 1; i <= 5; i++) dist.put(i, 0);

        String sql = "SELECT ratingvalue, COUNT(*) FROM rating "
                   + "WHERE courseid = ? GROUP BY ratingvalue";
        try (Connection conn = open();
             PreparedStatement stmt = conn.prepareStatement(sql))
        {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    int value = rs.getInt(1);
                    int count = rs.getInt(2);
                    if (value >= 1 && value <= 5) dist.put(value, count);
                }
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return dist;
    }
}
