package ISUStudentSurvival.model;

public class LoginResponse {
    private boolean requiresTwoFactor;
    private String challengeId;
    private String message;
    private Account account;

    public LoginResponse() {}

    public static LoginResponse success(Account account) {
        LoginResponse response = new LoginResponse();
        response.setRequiresTwoFactor(false);
        response.setAccount(account);
        return response;
    }

    public static LoginResponse twoFactorRequired(String challengeId, String message) {
        LoginResponse response = new LoginResponse();
        response.setRequiresTwoFactor(true);
        response.setChallengeId(challengeId);
        response.setMessage(message);
        return response;
    }

    public boolean isRequiresTwoFactor() {
        return requiresTwoFactor;
    }

    public void setRequiresTwoFactor(boolean requiresTwoFactor) {
        this.requiresTwoFactor = requiresTwoFactor;
    }

    public String getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(String challengeId) {
        this.challengeId = challengeId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }
}
