package ISUStudentSurvival.model;

public class Account
{
    private int accountId;
    private String email;
    private String name;
    private String department;
    private int yearValue;
    private String password;
    private String username;
    private String year;
    private boolean anonymity = false;
    private boolean notifications = true;
    private boolean twoFactorEnabled = false;

    public Account() {}

    public Account(String email, String password, String name, int yearValue, String year, String username, String department)
    {
        this.email = email;
        this.password = password;
        this.name = name;
        this.yearValue = yearValue;
        this.year = year;
        this.username = username;
        this.department = department;
    }

    public Account(int accountId, String name, String email, String password, int yearValue, String year, String username, String department)
    {
        this.accountId = accountId;
        this.name = name;
        this.email = email;
        this.password = password;
        this.yearValue = yearValue;
        this.year = year;
        this.username = username;
        this.department = department;
    }

    public int getAccountId() { return accountId; }
    public String getEmail() { return email; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public int getYearValue() { return yearValue; }
    public String getPassword() { return password; }
    public String getUsername() { return username; }
    public String getYear() { return year; }
    public boolean isAnonymity() { return anonymity; }
    public boolean isNotifications() { return notifications; }
    public boolean isTwoFactorEnabled() { return twoFactorEnabled; }

    public void setAccountId(int accountId) { this.accountId = accountId; }
    public void setEmail(String email) { this.email = email; }
    public void setName(String name) { this.name = name; }
    public void setDepartment(String department) { this.department = department; }
    public void setYearValue(int yearValue) { this.yearValue = yearValue; }
    public void setPassword(String password) { this.password = password; }
    public void setUsername(String username) { this.username = username; }
    public void setYear(String year) { this.year = year; }
    public void setAnonymity(boolean anonymity) { this.anonymity = anonymity; }
    public void setNotifications(boolean notifications) { this.notifications = notifications; }
    public void setTwoFactorEnabled(boolean twoFactorEnabled) { this.twoFactorEnabled = twoFactorEnabled; }

    public AccountSettings getSettings()
    {
        AccountSettings settings = new AccountSettings();
        if (anonymity) settings.toggleAnonymity();
        if (notifications) settings.toggleNotifications();
        return settings;
    }

    public void changePassword(String newPassword) { this.password = newPassword; }
}