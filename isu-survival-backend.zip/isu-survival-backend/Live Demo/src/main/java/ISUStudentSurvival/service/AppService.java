package ISUStudentSurvival.service;

import ISUStudentSurvival.SQLDBConnection;
import ISUStudentSurvival.app.SQLAccountHandler;
import ISUStudentSurvival.app.SQLCommentHandler;
import ISUStudentSurvival.app.SQLCommentLikeHandler;
import ISUStudentSurvival.app.SQLCourseHandler;
import ISUStudentSurvival.app.SQLCourseTagHandler;
import ISUStudentSurvival.app.SQLCourseTagNameHandler;
import ISUStudentSurvival.app.SQLDifficultyHandler;
import ISUStudentSurvival.app.SQLRatingHandler;
import ISUStudentSurvival.app.SQLSavedCourseHandler;
import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.ClassTag;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class AppService
{
    private final SQLDBConnection connection;
    private final SQLAccountHandler accountHandler;
    private final SQLCourseHandler courseHandler;
    private final SQLCommentHandler commentHandler;
    private final SQLRatingHandler ratingHandler;
    private final SQLDifficultyHandler difficultyHandler;
    private final SQLCourseTagHandler courseTagHandler;
    private final SQLCourseTagNameHandler courseTagNameHandler;
    private final SQLCommentLikeHandler commentLikeHandler;
    private final SQLSavedCourseHandler savedCourseHandler;

    @Autowired
    public AppService(SQLDBConnection connection)
    {
        this.connection = connection;
        this.accountHandler = new SQLAccountHandler(connection);
        this.courseHandler = new SQLCourseHandler(connection);
        this.commentHandler = new SQLCommentHandler(connection);
        this.ratingHandler = new SQLRatingHandler(connection);
        this.difficultyHandler = new SQLDifficultyHandler(connection);
        this.courseTagHandler = new SQLCourseTagHandler(connection);
        this.courseTagNameHandler = new SQLCourseTagNameHandler(connection);
        this.commentLikeHandler = new SQLCommentLikeHandler(connection, commentHandler);
        this.savedCourseHandler = new SQLSavedCourseHandler(connection);
    }

    // ============================================================
    //   Accounts
    // ============================================================

    public Account login(String username, String password)
    {
        List<Account> accounts = accountHandler.getAll();
        if (accounts == null) return null;
        for (Account a : accounts)
        {
            if (a.getUsername().equals(username) && a.getPassword().equals(password))
            {
                return a;
            }
        }
        return null;
    }

    public Account createAccount(String email, String password, String name, int yearValue, String year, String username, String department)
    {
        Account account = new Account(email, password, name, yearValue, year, username, department);
        boolean success = accountHandler.create(account);
        if (!success) return null;
        return account;
    }

    public Account getAccountById(int id)
    {
        return accountHandler.getById(id);
    }

    public Account updateAccount(int id, String email, String name, String department, Integer yearValue, String year, String username, String password)
    {
        Account existing = accountHandler.getById(id);
        if (existing == null) return null;
        if (email != null) existing.setEmail(email);
        if (name != null) existing.setName(name);
        if (department != null) existing.setDepartment(department);
        if (yearValue != null) existing.setYearValue(yearValue);
        if (year != null) existing.setYear(year);
        if (username != null) existing.setUsername(username);
        if (password != null && !password.isBlank()) existing.setPassword(password);
        boolean success = accountHandler.update(existing);
        return success ? existing : null;
    }

    public boolean deleteAccount(int id)
    {
        return accountHandler.delete(id);
    }

    public Account updateAccountSettings(int id, Boolean anonymity, Boolean notifications)
    {
        Account existing = accountHandler.getById(id);
        if (existing == null) return null;
        if (anonymity != null) existing.setAnonymity(anonymity);
        if (notifications != null) existing.setNotifications(notifications);
        boolean success = accountHandler.update(existing);
        return success ? existing : null;
    }

    // ============================================================
    //   Courses (with optional sort by rating / difficulty / etc.)
    // ============================================================

    /**
     * Returns all courses with an optional sort key. Supported sort values:
     *   "rating"     — descending average star rating (3.1.10)
     *   "difficulty" — ascending average difficulty (3.1.15) — easier first
     *   anything else / null — natural order from the DB
     *
     * Average lookups happen per-course in a small in-memory join because
     * the dataset is tiny. If the course count grows beyond a few hundred,
     * promote this to a single SQL query with a GROUP BY.
     */
    public List<Course> getAllCourses(String sortBy, Integer requesterId)
    {
        List<Course> courses = courseHandler.getAll();
        if (courses == null) return null;

        // Mark which courses the requester has bookmarked, in one query.
        if (requesterId != null)
        {
            Set<Integer> savedIds = savedCourseHandler.getSavedCourseIds(requesterId);
            for (Course c : courses)
            {
                c.setSavedByMe(savedIds.contains(c.getCourseId()));
            }
        }

        if ("rating".equalsIgnoreCase(sortBy))
        {
            courses.sort(Comparator.comparingDouble(
                    (Course c) -> nullToNegInf(ratingHandler.getAverageForCourse(c.getCourseId()))).reversed());
        }
        else if ("difficulty".equalsIgnoreCase(sortBy))
        {
            courses.sort(Comparator.comparingDouble(
                    (Course c) -> nullToPosInf(difficultyHandler.getAverageForCourse(c.getCourseId()))));
        }
        return courses;
    }

    private double nullToNegInf(Double d) { return d == null ? Double.NEGATIVE_INFINITY : d; }
    private double nullToPosInf(Double d) { return d == null ? Double.POSITIVE_INFINITY : d; }

    public Course getCourseById(int id)
    {
        return courseHandler.getById(id);
    }

    public Course createCourse(String courseName, int courseCode, String department)
    {
        Course course = new Course(courseName, courseCode, department);
        boolean success = courseHandler.create(course);
        if (!success) return null;
        return course;
    }

    public Course updateCourse(int id, String courseName, Integer courseCode, String department)
    {
        Course existing = courseHandler.getById(id);
        if (existing == null) return null;
        if (courseName != null) existing.setCourseName(courseName);
        if (courseCode != null) existing.setCourseCode(courseCode);
        if (department != null) existing.setDepartment(department);
        boolean success = courseHandler.update(existing);
        return success ? existing : null;
    }

    public boolean deleteCourse(int id)
    {
        return courseHandler.delete(id);
    }

    public List<Course> searchCourses(String query)
    {
        return courseHandler.search(query);
    }

    public List<Course> filterCoursesByLevel(int level)
    {
        return courseHandler.filterByCourseLevel(level);
    }

    /** Aggregate stats for the course-detail header. */
    public Double getCourseAverageRating(int courseId)
    {
        return ratingHandler.getAverageForCourse(courseId);
    }

    public Double getCourseAverageDifficulty(int courseId)
    {
        return difficultyHandler.getAverageForCourse(courseId);
    }

    /** 3.1.24 — bar-chart distribution of 1..5 star counts. */
    public Map<Integer, Integer> getCourseRatingDistribution(int courseId)
    {
        return ratingHandler.getDistributionForCourse(courseId);
    }

    // ============================================================
    //   Comments (now atomic: comment + rating + difficulty + tags)
    // ============================================================

    /**
     * Returns comments for a course with each comment enriched with its
     * rating, difficulty, tag list, and (if accountId != null) whether
     * the requesting user has liked it. Supports an optional sort by
     * "likes" for use case 3.1.11.
     */
    public List<Comment> getCommentsByCourseId(int courseId, Integer requesterId, String sortBy)
    {
        List<Comment> comments = commentHandler.getByCourseId(courseId);
        if (comments == null) return new ArrayList<>();

        // Enrich each comment with rating / difficulty / tags. Per-comment
        // queries are fine for the demo; a fancier impl would batch these.
        for (Comment c : comments)
        {
            c.setRating(ratingHandler.getRatingForComment(c.getCommentId()));
            c.setDifficulty(difficultyHandler.getDifficultyForComment(c.getCommentId()));
            c.setTags(courseTagHandler.getTagsForComment(c.getCommentId()));
        }

        // Mark which comments the requester has liked, in one query.
        if (requesterId != null)
        {
            List<Integer> ids = new ArrayList<>(comments.size());
            for (Comment c : comments) ids.add(c.getCommentId());
            Set<Integer> liked = commentLikeHandler.getLikedSubset(requesterId, ids);
            for (Comment c : comments)
            {
                c.setLikedByMe(liked.contains(c.getCommentId()));
            }
        }

        if ("likes".equalsIgnoreCase(sortBy))
        {
            comments.sort(Comparator.comparingInt(Comment::getLikes).reversed());
        }

        return comments;
    }

    /**
     * Atomic comment-creation: writes a row into commentinfo, then in the
     * same transaction writes optional rating, difficulty, and tag rows
     * sharing the new commentid. If anything fails, the entire submission
     * rolls back so we never end up with a comment but no rating, etc.
     */
    public Comment addComment(String content, int accountId, int courseId, Integer parentCommentId,
                              Integer ratingValue, Integer difficultyValue, List<Integer> tagNameIds)
    {
        if (content == null || content.isBlank()) return null;

        Comment comment = new Comment();
        comment.setComment(content);
        comment.setAccountId(accountId);
        comment.setCourseId(courseId);
        comment.setParentCommentId(parentCommentId);

        Connection conn = null;
        try
        {
            conn = connection.getConnection();
            conn.setAutoCommit(false);

            boolean ok = commentHandler.createOnConnection(comment, conn);
            if (!ok) { conn.rollback(); return null; }

            int newId = comment.getCommentId();
            // Replies skip rating / difficulty / tags — they only apply to top-level reviews.
            boolean isReply = (parentCommentId != null);

            if (!isReply && ratingValue != null && ratingValue >= 1 && ratingValue <= 5)
            {
                ratingHandler.addRating(courseId, newId, ratingValue, conn);
                comment.setRating(ratingValue);
            }
            if (!isReply && difficultyValue != null && difficultyValue >= 1 && difficultyValue <= 5)
            {
                difficultyHandler.addDifficulty(courseId, newId, difficultyValue, conn);
                comment.setDifficulty(difficultyValue);
            }
            if (!isReply && tagNameIds != null && !tagNameIds.isEmpty())
            {
                List<ClassTag> attached = new ArrayList<>();
                for (Integer tagNameId : tagNameIds)
                {
                    if (tagNameId == null) continue;
                    courseTagHandler.addTag(courseId, newId, tagNameId, conn);
                    ClassTag t = courseTagNameHandler.getById(tagNameId);
                    if (t != null) attached.add(t);
                }
                comment.setTags(attached);
            }

            conn.commit();
            return comment;
        }
        catch (SQLException e)
        {
            if (conn != null)
            {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace();
            return null;
        }
        finally
        {
            if (conn != null)
            {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    public Comment editComment(int commentId, int requesterId, String newContent)
    {
        if (newContent == null || newContent.isBlank()) return null;
        Comment existing = commentHandler.getById(commentId);
        if (existing == null) return null;
        if (existing.getAccountId() != requesterId) return null;
        existing.setComment(newContent);
        boolean success = commentHandler.update(existing);
        if (!success) return null;
        return commentHandler.getById(commentId);
    }

    public boolean deleteComment(int commentId, int requesterId)
    {
        Comment existing = commentHandler.getById(commentId);
        if (existing == null) return false;
        if (existing.getAccountId() != requesterId) return false;
        return commentHandler.delete(commentId);
    }

    // ============================================================
    //   Tags lookup (for the chip-picker on the comment form)
    // ============================================================

    public List<ClassTag> getAllTagNames()
    {
        return courseTagNameHandler.getAll();
    }

    // ============================================================
    //   Likes (3.1.7 / 3.1.11)
    // ============================================================

    public boolean likeComment(int commentId, int accountId)
    {
        return commentLikeHandler.like(commentId, accountId);
    }

    public boolean unlikeComment(int commentId, int accountId)
    {
        return commentLikeHandler.unlike(commentId, accountId);
    }

    // ============================================================
    //   Saved Courses (3.1.19 Save / 3.1.20 Remove)
    // ============================================================

    public boolean saveCourse(int accountId, int courseId)
    {
        return savedCourseHandler.save(accountId, courseId);
    }

    public boolean unsaveCourse(int accountId, int courseId)
    {
        return savedCourseHandler.unsave(accountId, courseId);
    }

    /**
     * Returns the list of courses the user has bookmarked, with each
     * course pre-marked savedByMe=true so the UI doesn't have to flag
     * them itself.
     */
    public List<Course> getSavedCourses(int accountId)
    {
        List<Course> saved = savedCourseHandler.getSavedCourses(accountId);
        for (Course c : saved) c.setSavedByMe(true);
        return saved;
    }
}
