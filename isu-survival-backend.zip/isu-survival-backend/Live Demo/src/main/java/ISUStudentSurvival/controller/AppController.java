package ISUStudentSurvival.controller;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.ClassTag;
import ISUStudentSurvival.model.Comment;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
public class AppController
{
    @Autowired
    private AppService appService;

    @PostMapping("/account/login")
    public ResponseEntity<Account> login(@RequestParam String username, @RequestParam String password)
    {
        Account account = appService.login(username, password);
        if (account == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(account);
    }

    @PostMapping("/account/create")
    public ResponseEntity<Account> createAccount(
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String name,
            @RequestParam(defaultValue = "1") int yearValue,
            @RequestParam(defaultValue = "") String year,
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String department)
    {
        Account account = appService.createAccount(email, password, name, yearValue, year, username, department);
        if (account == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(account);
    }

    @PutMapping("/account/{id}")
    public ResponseEntity<Account> updateAccount(
            @PathVariable int id,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) Integer yearValue,
            @RequestParam(required = false) String year,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String password)
    {
        Account account = appService.updateAccount(id, email, name, department, yearValue, year, username, password);
        if (account == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(account);
    }

    @DeleteMapping("/account/{id}")
    public ResponseEntity<Void> deleteAccount(@PathVariable int id)
    {
        boolean success = appService.deleteAccount(id);
        if (!success) return ResponseEntity.status(400).build();
        return ResponseEntity.ok().build();
    }

    @PutMapping("/account/{id}/settings")
    public ResponseEntity<Account> updateAccountSettings(
            @PathVariable int id,
            @RequestParam(required = false) Boolean anonymity,
            @RequestParam(required = false) Boolean notifications)
    {
        Account account = appService.updateAccountSettings(id, anonymity, notifications);
        if (account == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(account);
    }

    @GetMapping("/courses")
    public List<Course> getAllCourses(
            @RequestParam(required = false) String sort,
            @RequestParam(required = false) Integer accountId)
    {
        return appService.getAllCourses(sort, accountId);
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<Course> getCourse(@PathVariable int id)
    {
        Course course = appService.getCourseById(id);
        if (course == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(course);
    }

    @GetMapping("/courses/search")
    public List<Course> searchCourses(@RequestParam(defaultValue = "") String q)
    {
        return appService.searchCourses(q);
    }

    @GetMapping("/courses/level/{level}")
    public List<Course> filterCoursesByLevel(@PathVariable int level)
    {
        return appService.filterCoursesByLevel(level);
    }

    @PostMapping("/course/create")
    public ResponseEntity<Course> createCourse(
            @RequestParam String courseName,
            @RequestParam int courseCode,
            @RequestParam String department)
    {
        Course course = appService.createCourse(courseName, courseCode, department);
        if (course == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(course);
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<Course> updateCourse(
            @PathVariable int id,
            @RequestParam(required = false) String courseName,
            @RequestParam(required = false) Integer courseCode,
            @RequestParam(required = false) String department)
    {
        Course course = appService.updateCourse(id, courseName, courseCode, department);
        if (course == null) return ResponseEntity.status(404).build();
        return ResponseEntity.ok(course);
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable int id)
    {
        boolean success = appService.deleteCourse(id);
        if (!success) return ResponseEntity.status(400).build();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/comments/{courseId}")
    public List<Comment> getComments(
            @PathVariable int courseId,
            @RequestParam(required = false) Integer accountId,
            @RequestParam(required = false) String sort)
    {
        return appService.getCommentsByCourseId(courseId, accountId, sort);
    }

    /**
     * Atomic create: comment + (optional) rating + (optional) difficulty
     * + (optional) tag list. Tags arrive as a comma-separated id list,
     * e.g. tagIds=1,4,7 — keeps the URL-form post call site simple.
     */
    @PostMapping("/comment/create")
    public ResponseEntity<Comment> createComment(
            @RequestParam String comment,
            @RequestParam int accountId,
            @RequestParam int courseId,
            @RequestParam(required = false) Integer parentCommentId,
            @RequestParam(required = false) Integer rating,
            @RequestParam(required = false) Integer difficulty,
            @RequestParam(required = false) String tagIds)
    {
        List<Integer> tagIdList = parseTagIds(tagIds);
        Comment created = appService.addComment(
                comment, accountId, courseId, parentCommentId,
                rating, difficulty, tagIdList);
        if (created == null) return ResponseEntity.status(400).build();
        return ResponseEntity.ok(created);
    }

    private List<Integer> parseTagIds(String csv)
    {
        List<Integer> out = new ArrayList<>();
        if (csv == null || csv.isBlank()) return out;
        for (String part : csv.split(","))
        {
            String trimmed = part.trim();
            if (trimmed.isEmpty()) continue;
            try { out.add(Integer.parseInt(trimmed)); }
            catch (NumberFormatException ignored) {}
        }
        return out;
    }

    @PutMapping("/comment/{id}")
    public ResponseEntity<Comment> updateComment(
            @PathVariable int id,
            @RequestParam String comment,
            @RequestParam int accountId)
    {
        Comment updated = appService.editComment(id, accountId, comment);
        if (updated == null) return ResponseEntity.status(403).build();
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/comment/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable int id, @RequestParam int accountId)
    {
        boolean success = appService.deleteComment(id, accountId);
        if (!success) return ResponseEntity.status(403).build();
        return ResponseEntity.ok().build();
    }

    // ============================================================
    //   Tags (3.1.18) — lookup the available chip set for the form
    // ============================================================

    @GetMapping("/tags")
    public List<ClassTag> getAllTags()
    {
        return appService.getAllTagNames();
    }

    // ============================================================
    //   Likes (3.1.7 like / unlike)
    // ============================================================

    @PostMapping("/comment/{id}/like")
    public ResponseEntity<Void> likeComment(@PathVariable int id, @RequestParam int accountId)
    {
        boolean ok = appService.likeComment(id, accountId);
        // false here is most often the unique-key violation (already liked).
        if (!ok) return ResponseEntity.status(409).build();
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/comment/{id}/like")
    public ResponseEntity<Void> unlikeComment(@PathVariable int id, @RequestParam int accountId)
    {
        boolean ok = appService.unlikeComment(id, accountId);
        if (!ok) return ResponseEntity.status(404).build();
        return ResponseEntity.ok().build();
    }

    // ============================================================
    //   Course aggregates — power the rating cards + distribution
    // ============================================================

    @GetMapping("/courses/{id}/stats")
    public Map<String, Object> getCourseStats(@PathVariable int id)
    {
        Map<String, Object> stats = new java.util.LinkedHashMap<>();
        stats.put("averageRating", appService.getCourseAverageRating(id));
        stats.put("averageDifficulty", appService.getCourseAverageDifficulty(id));
        return stats;
    }

    /** 3.1.24 — five-bar distribution of star counts. */
    @GetMapping("/courses/{id}/rating-distribution")
    public Map<Integer, Integer> getCourseRatingDistribution(@PathVariable int id)
    {
        return appService.getCourseRatingDistribution(id);
    }

    // ============================================================
    //   Saved Courses (3.1.19 / 3.1.20)
    // ============================================================

    @GetMapping("/account/{id}/saved-courses")
    public List<Course> getSavedCourses(@PathVariable int id)
    {
        return appService.getSavedCourses(id);
    }

    @PostMapping("/account/{id}/saved-courses")
    public ResponseEntity<Void> saveCourse(@PathVariable int id, @RequestParam int courseId)
    {
        boolean ok = appService.saveCourse(id, courseId);
        // false here is most often the unique-key violation (already saved).
        if (!ok) return ResponseEntity.status(409).build();
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/account/{id}/saved-courses")
    public ResponseEntity<Void> unsaveCourse(@PathVariable int id, @RequestParam int courseId)
    {
        boolean ok = appService.unsaveCourse(id, courseId);
        if (!ok) return ResponseEntity.status(404).build();
        return ResponseEntity.ok().build();
    }
    public void setAppService(AppService appService) {
        this.appService = appService;
    }
}
