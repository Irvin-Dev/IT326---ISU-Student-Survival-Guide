import React, { useState } from 'react';

const API = 'http://localhost:8080';

export default function LoginPage({ navigate, setUser }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async () => {
    setError('');
    if (!form.username || !form.password) { setError('Please fill in all fields.'); return; }
    setLoading(true);
    try {
      const res = await fetch(`${API}/account/login?username=${form.username}&password=${form.password}`, { method: 'POST' });
      if (res.ok) {
        const user = await res.json();
        setUser(user);
        navigate('main');
      } else {
        setError('Invalid username or password.');
      }
    } catch {
      setError('Could not connect to server.');
    }
    setLoading(false);
  };

  return (
    <div className="form-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
        </div>
      </nav>
      <div className="form-wrap">
        <div className="form-card">
          <div className="form-title">SIGN IN</div>
          <div className="form-subtitle">Welcome back, Redbird.</div>

          {error && <div className="form-error">{error}</div>}

          <div className="form-group">
            <label className="form-label">Username</label>
            <input className="form-input" name="username" value={form.username} onChange={handle} placeholder="your_username" />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="••••••••" />
          </div>

          <button className="form-btn" onClick={submit} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>

          <div className="form-footer">
            Don't have an account?{' '}
            <button className="form-link" onClick={() => navigate('register')}>Register here</button>
          </div>
        </div>
      </div>
    </div>
  );
}
