import React, { useState } from 'react';

const API = 'http://localhost:8080';

export default function LoginPage({ navigate, setUser }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [code, setCode] = useState('');
  const [challengeId, setChallengeId] = useState('');
  const [requires2FA, setRequires2FA] = useState(false);
  const [info, setInfo] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async () => {
    setError('');
    setInfo('');
    if (!form.username || !form.password) { setError('Please fill in all fields.'); return; }
    setLoading(true);
    try {
      const res = await fetch(
        `${API}/account/login?username=${encodeURIComponent(form.username)}&password=${encodeURIComponent(form.password)}`,
        { method: 'POST' }
      );
      if (res.ok) {
        const data = await res.json();
        if (data.requiresTwoFactor) {
          setRequires2FA(true);
          setChallengeId(data.challengeId || '');
          setInfo(data.message || 'Enter your one-time code.');
        } else {
          const user = data.account || data;
          setUser(user);
          navigate('main');
        }
      } else {
        // 401 = credentials don't match.
        if (res.status === 401) {
          setError('Invalid username or password.');
        // 503 = credentials were valid, but backend could not send 2FA email.
        } else if (res.status === 503) {
          setError('Credentials were correct, but we could not send your 2FA email code. Please check Gmail app-password settings and try again.');
        } else {
          setError('Sign-in failed. Please try again.');
        }
      }
    } catch {
      setError('Could not connect to server.');
    }
    setLoading(false);
  };

  const verifyCode = async () => {
    setError('');
    setInfo('');
    if (!challengeId || !code.trim()) {
      setError('Please enter the 2FA code.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(
        `${API}/account/login/verify-2fa?challengeId=${encodeURIComponent(challengeId)}&code=${encodeURIComponent(code.trim())}`,
        { method: 'POST' }
      );
      if (res.ok) {
        const user = await res.json();
        setUser(user);
        navigate('main');
      } else {
        setError('Invalid/expired code, or max attempts reached. Sign in again.');
      }
    } catch {
      setError('Could not connect to server.');
    }
    setLoading(false);
  };

  const resetFlow = () => {
    setRequires2FA(false);
    setChallengeId('');
    setCode('');
    setInfo('');
    setError('');
  };

  return (
    <div className="form-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
        </div>
      </nav>
      <div className="form-wrap">
        <div className="form-card">
          <div className="form-title">SIGN IN</div>
          <div className="form-subtitle">Welcome back, Redbird.</div>

          {error && <div className="form-error">{error}</div>}
          {info && <div className="form-success">{info}</div>}

          {!requires2FA ? (
            <>
              <div className="form-group">
                <label className="form-label">Username</label>
                <input className="form-input" name="username" value={form.username} onChange={handle} placeholder="your_username" />
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="••••••••" />
              </div>

              <button className="form-btn" onClick={submit} disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </>
          ) : (
            <>
              <div className="form-group">
                <label className="form-label">2FA Code</label>
                <input
                  className="form-input"
                  value={code}
                  onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="Enter 6-digit code"
                />
              </div>

              <button className="form-btn" onClick={verifyCode} disabled={loading}>
                {loading ? 'Verifying...' : 'Verify Code'}
              </button>
              <button className="nav-btn" style={{ marginTop: '0.8rem' }} onClick={resetFlow} disabled={loading}>
                Start over
              </button>
            </>
          )}

          <div className="form-footer">
            Don't have an account?{' '}
            <button className="form-link" onClick={() => navigate('register')}>Register here</button>
          </div>
        </div>
      </div>
    </div>
  );
}
