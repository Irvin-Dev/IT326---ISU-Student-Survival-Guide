import React, { useState, useEffect } from 'react';

const API = 'http://localhost:8080';

export default function MainPage({ navigate, user, logout }) {
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API}/courses`)
      .then(r => r.json())
      .then(data => { setCourses(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = courses.filter(c =>
    c.courseName?.toLowerCase().includes(search.toLowerCase()) ||
    c.department?.toLowerCase().includes(search.toLowerCase()) ||
    String(c.courseCode).includes(search)
  );

  return (
    <div>
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user ? (
            <>
              <div className="nav-user">
                <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span>{user.username}</span>
              </div>
              <button className="nav-btn" onClick={logout}>Sign Out</button>
            </>
          ) : (
            <>
              <button className="nav-btn" onClick={() => navigate('login')}>Sign In</button>
              <button className="nav-btn primary" onClick={() => navigate('register')}>Register</button>
            </>
          )}
        </div>
      </nav>

      <div className="hero">
        <div className="hero-inner">
          <div className="hero-tag">Illinois State University</div>
          <h1>FIND YOUR <span>COURSE</span></h1>
          <p>Student-driven reviews and ratings to help you survive ISU. Real feedback from real Redbirds.</p>
          <div className="search-wrap">
            <input
              className="search-input"
              placeholder="Search by name, department, or code..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <button className="search-btn">Search</button>
          </div>
        </div>
      </div>

      <div className="main-content">
        <div className="section-label">
          {search ? `Results for "${search}"` : 'All Courses'}
        </div>

        {loading ? (
          <div className="loading">Loading courses...</div>
        ) : filtered.length === 0 ? (
          <div className="empty">No courses found.</div>
        ) : (
          <div className="course-grid">
            {filtered.map(course => (
              <div
                key={course.courseId}
                className="course-card"
                onClick={() => navigate('course', course)}
              >
                <div className="course-dept">{course.department}</div>
                <div className="course-code">CODE {course.courseCode}</div>
                <div className="course-name">{course.courseName}</div>
                <div className="course-stats">
                  <div className="stat">Click to view details</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
