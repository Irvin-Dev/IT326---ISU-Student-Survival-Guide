import React, { useState, useEffect, useMemo } from 'react';

const API = 'http://localhost:8080';

export default function MainPage({ navigate, user, logout, setCompareSet }) {
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState('');
  const [level, setLevel] = useState('all');
  const [department, setDepartment] = useState('all');
  const [sortBy, setSortBy] = useState('code');
  const [showSavedOnly, setShowSavedOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState({ courseName: '', courseCode: '', department: '' });
  const [createError, setCreateError] = useState('');
  const [creating, setCreating] = useState(false);

  const [compareMode, setCompareMode] = useState(false);
  const [selected, setSelected] = useState([]);

  const loadCourses = () => {
    setLoading(true);
    // Rating + difficulty need backend sorting (the data isn't in the courses
    // payload). Code/name/dept are client-side so sort changes don't refetch.
    const serverSorts = ['rating', 'difficulty'];
    const params = new URLSearchParams();
    if (serverSorts.includes(sortBy)) params.set('sort', sortBy);
    // Pass accountId so the backend marks savedByMe on each course.
    if (user) params.set('accountId', String(user.accountId));
    const qs = params.toString();
    const url = qs ? `${API}/courses?${qs}` : `${API}/courses`;
    fetch(url)
      .then(r => r.json())
      .then(data => { setCourses(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(loadCourses, [sortBy, user]);

  // Optimistic save toggle — flip locally, then call backend; revert on failure.
  const toggleSave = async (e, course) => {
    e.stopPropagation();
    if (!user) { navigate('login'); return; }
    const willSave = !course.savedByMe;
    setCourses(prev => prev.map(c =>
      c.courseId === course.courseId ? { ...c, savedByMe: willSave } : c
    ));
    const url = `${API}/account/${user.accountId}/saved-courses?courseId=${course.courseId}`;
    const method = willSave ? 'POST' : 'DELETE';
    try {
      const res = await fetch(url, { method });
      if (!res.ok) {
        // Surface the failure so we can tell whether it's a 404 (Spring not
        // restarted), 409 (already in that state), or 500 (table missing).
        console.error(`[saved-course] ${method} ${url} -> ${res.status}`);
        const body = await res.text().catch(() => '');
        if (body) console.error('[saved-course] body:', body);
        if (res.status === 404 && willSave === false) {
          // Already not saved on server — keep optimistic state, don't revert.
          return;
        }
        if (res.status === 409 && willSave === true) {
          // Already saved on server — keep optimistic state, don't revert.
          return;
        }
        // Genuine failure — revert by reloading from server.
        loadCourses();
      }
    } catch (err) {
      console.error('[saved-course] network error', err);
      loadCourses();
    }
  };

  const departments = useMemo(() => {
    const set = new Set(courses.map(c => c.department).filter(Boolean));
    return Array.from(set).sort();
  }, [courses]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    let out = courses.filter(c => {
      if (showSavedOnly && !c.savedByMe) return false;
      if (q) {
        const hit =
          c.courseName?.toLowerCase().includes(q) ||
          c.department?.toLowerCase().includes(q) ||
          String(c.courseCode).includes(q);
        if (!hit) return false;
      }
      if (department !== 'all' && c.department !== department) return false;
      if (level !== 'all') {
        const lvl = parseInt(level, 10);
        if (!(c.courseCode >= lvl && c.courseCode < lvl + 100)) return false;
      }
      return true;
    });
    if (sortBy === 'code') out.sort((a, b) => (a.courseCode || 0) - (b.courseCode || 0));
    else if (sortBy === 'name') out.sort((a, b) => (a.courseName || '').localeCompare(b.courseName || ''));
    else if (sortBy === 'dept') out.sort((a, b) => (a.department || '').localeCompare(b.department || ''));
    // 'rating' and 'difficulty' are pre-sorted by the backend; preserve order.
    return out;
  }, [courses, search, level, department, sortBy, showSavedOnly]);

  const resetFilters = () => { setSearch(''); setLevel('all'); setDepartment('all'); setSortBy('code'); setShowSavedOnly(false); };
  const filtersActive = search || level !== 'all' || department !== 'all' || sortBy !== 'code' || showSavedOnly;

  const submitCreate = async () => {
    setCreateError('');
    const { courseName, courseCode, department } = createForm;
    if (!courseName || !courseCode || !department) { setCreateError('Please fill in all fields.'); return; }
    if (!/^\d+$/.test(courseCode)) { setCreateError('Course code must be a number.'); return; }
    setCreating(true);
    try {
      const res = await fetch(
        `${API}/course/create?courseName=${encodeURIComponent(courseName)}&courseCode=${courseCode}&department=${encodeURIComponent(department)}`,
        { method: 'POST' }
      );
      if (res.ok) {
        setShowCreate(false);
        setCreateForm({ courseName: '', courseCode: '', department: '' });
        loadCourses();
      } else {
        setCreateError('Could not create course. A course with that name may already exist.');
      }
    } catch {
      setCreateError('Could not connect to server.');
    }
    setCreating(false);
  };

  const toggleSelected = (id) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : (prev.length < 2 ? [...prev, id] : prev));
  };

  const startCompare = () => {
    const pair = courses.filter(c => selected.includes(c.courseId));
    if (pair.length === 2) {
      setCompareSet(pair);
      navigate('compare');
    }
  };

  const exitCompare = () => { setCompareMode(false); setSelected([]); };

  return (
    <div>
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user ? (
            <>
              <button className="nav-btn" onClick={() => navigate('settings')}>Settings</button>
              <div className="nav-user">
                <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span>{user.username}</span>
              </div>
              <button className="nav-btn" onClick={logout}>Sign Out</button>
            </>
          ) : (
            <>
              <button className="nav-btn" onClick={() => navigate('login')}>Sign In</button>
              <button className="nav-btn primary" onClick={() => navigate('register')}>Register</button>
            </>
          )}
        </div>
      </nav>

      <div className="hero">
        <div className="hero-inner">
          <div className="hero-tag">Illinois State University</div>
          <h1>FIND YOUR <span>COURSE</span></h1>
          <p>Student-driven reviews and ratings to help you survive ISU. Real feedback from real Redbirds.</p>
          <div className="search-wrap">
            <input
              className="search-input"
              placeholder="Search by name, department, or code..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <button className="search-btn">Search</button>
          </div>
        </div>
      </div>

      <div className="main-content">
        <div className="filter-bar">
          <div className="filter-group">
            <label className="filter-label">Department</label>
            <select className="filter-select" value={department} onChange={e => setDepartment(e.target.value)}>
              <option value="all">All</option>
              {departments.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <div className="filter-group">
            <label className="filter-label">Level</label>
            <select className="filter-select" value={level} onChange={e => setLevel(e.target.value)}>
              <option value="all">All</option>
              <option value="100">100-level</option>
              <option value="200">200-level</option>
              <option value="300">300-level</option>
              <option value="400">400-level</option>
              <option value="500">500-level</option>
            </select>
          </div>
          <div className="filter-group">
            <label className="filter-label">Sort by</label>
            <select className="filter-select" value={sortBy} onChange={e => setSortBy(e.target.value)}>
              <option value="code">Course code</option>
              <option value="name">Course name</option>
              <option value="dept">Department</option>
              <option value="rating">Highest rated</option>
              <option value="difficulty">Easiest first</option>
            </select>
          </div>
          {user && (
            <button
              className="filter-reset"
              onClick={() => setShowSavedOnly(s => !s)}
              style={{
                background: showSavedOnly ? '#cf2030' : undefined,
                color: showSavedOnly ? '#fff' : undefined,
                borderColor: showSavedOnly ? '#cf2030' : undefined
              }}
              title="Show only courses you've saved"
            >
              {showSavedOnly ? '★ Saved only' : '☆ Show saved'}
            </button>
          )}
          {filtersActive && (
            <button className="filter-reset" onClick={resetFilters}>Reset</button>
          )}
          <div className="filter-count">{visible.length} of {courses.length} courses</div>
        </div>

        <div className="action-bar">
          {user && !compareMode && (
            <button className="action-btn primary" onClick={() => setShowCreate(true)}>+ Create Course</button>
          )}
          {!compareMode ? (
            <button className="action-btn" onClick={() => setCompareMode(true)}>Compare Courses</button>
          ) : (
            <>
              <span className="compare-status">
                {selected.length === 0 ? 'Pick 2 courses to compare' :
                 selected.length === 1 ? 'Pick 1 more' :
                 'Ready to compare'}
              </span>
              <button className="action-btn primary" onClick={startCompare} disabled={selected.length !== 2}>Compare</button>
              <button className="action-btn" onClick={exitCompare}>Cancel</button>
            </>
          )}
        </div>

        <div className="section-label">
          {search ? `Results for "${search}"` : 'All Courses'}
        </div>

        {loading ? (
          <div className="loading">Loading courses...</div>
        ) : visible.length === 0 ? (
          <div className="empty">No courses found.</div>
        ) : (
          <div className="course-grid">
            {visible.map(course => {
              const isSelected = selected.includes(course.courseId);
              return (
                <div
                  key={course.courseId}
                  className={`course-card ${compareMode ? 'compare-card' : ''} ${isSelected ? 'selected' : ''}`}
                  onClick={() => compareMode ? toggleSelected(course.courseId) : navigate('course', course)}
                  style={{ position: 'relative' }}
                >
                  {compareMode && (
                    <div className="compare-checkbox">
                      <input type="checkbox" checked={isSelected} readOnly />
                    </div>
                  )}
                  {user && !compareMode && (
                    <button
                      onClick={(e) => toggleSave(e, course)}
                      title={course.savedByMe ? 'Remove from saved' : 'Save course'}
                      style={{
                        position: 'absolute',
                        top: 10,
                        right: 12,
                        background: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: 22,
                        lineHeight: 1,
                        color: course.savedByMe ? '#cf2030' : '#bbb',
                        padding: 0
                      }}
                    >
                      {course.savedByMe ? '★' : '☆'}
                    </button>
                  )}
                  <div className="course-dept">{course.department}</div>
                  <div className="course-code">CODE {course.courseCode}</div>
                  <div className="course-name">{course.courseName}</div>
                  <div className="course-stats">
                    <div className="stat">{compareMode ? (isSelected ? 'Selected' : 'Click to select') : 'Click to view details'}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showCreate && (
        <div className="modal-overlay" onClick={() => setShowCreate(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">CREATE COURSE</div>
            <div className="modal-subtitle">Add a new course page.</div>
            {createError && <div className="form-error">{createError}</div>}
            <div className="form-group">
              <label className="form-label">Course Name</label>
              <input className="form-input" value={createForm.courseName}
                     onChange={e => setCreateForm({ ...createForm, courseName: e.target.value })}
                     placeholder="Intro to Software Engineering" />
            </div>
            <div className="form-group">
              <label className="form-label">Course Code</label>
              <input className="form-input" value={createForm.courseCode}
                     onChange={e => setCreateForm({ ...createForm, courseCode: e.target.value })}
                     placeholder="326" />
            </div>
            <div className="form-group">
              <label className="form-label">Department</label>
              <input className="form-input" value={createForm.department}
                     onChange={e => setCreateForm({ ...createForm, department: e.target.value })}
                     placeholder="IT" />
            </div>
            <div className="modal-actions">
              <button className="action-btn" onClick={() => setShowCreate(false)}>Cancel</button>
              <button className="action-btn primary" onClick={submitCreate} disabled={creating}>
                {creating ? 'Creating...' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
