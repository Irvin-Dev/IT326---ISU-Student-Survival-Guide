import React, { useState } from 'react';

const API = 'http://localhost:8080';

export default function RegisterPage({ navigate, setUser }) {
  const [form, setForm] = useState({ name: '', username: '', email: '', password: '', year: '' });
  const [verificationCode, setVerificationCode] = useState('');
  const [codeRequested, setCodeRequested] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const requestCode = async () => {
    setError('');
    setSuccess('');
    const { name, username, email, password, year } = form;
    if (!name || !username || !email || !password || !year) { setError('Please fill in all fields.'); return; }

    setLoading(true);
    try {
      const res = await fetch(
        `${API}/account/create/request-code?email=${encodeURIComponent(email)}`,
        { method: 'POST' }
      );
      if (res.ok) {
        setCodeRequested(true);
        setSuccess('Verification code sent to your email. Enter it below to finish creating your account.');
      } else {
        setError('Could not send verification code. Email may already be in use or SMTP is not configured.');
      }
    } catch {
      setError('Could not connect to server.');
    }
    setLoading(false);
  };

  const submit = async () => {
    setError('');
    setSuccess('');
    const { name, username, email, password, year } = form;
    if (!name || !username || !email || !password || !year) { setError('Please fill in all fields.'); return; }
    if (!verificationCode.trim()) { setError('Enter the verification code sent to your email.'); return; }

    setLoading(true);
    try {
      const res = await fetch(
        `${API}/account/create?name=${encodeURIComponent(name)}&username=${encodeURIComponent(username)}&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&year=${encodeURIComponent(year)}&twoFactorEnabled=${twoFactorEnabled}&verificationCode=${encodeURIComponent(verificationCode.trim())}`,
        { method: 'POST' }
      );
      if (res.ok) {
        const user = await res.json();
        setSuccess('Account created! Redirecting...');
        setUser(user);
        setTimeout(() => navigate('main'), 1500);
      } else {
        setError('Could not create account. Invalid/expired code, too many attempts, or account data conflict.');
      }
    } catch {
      setError('Could not connect to server.');
    }
    setLoading(false);
  };

  return (
    <div className="form-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
        </div>
      </nav>
      <div className="form-wrap">
        <div className="form-card">
          <div className="form-title">REGISTER</div>
          <div className="form-subtitle">Join the Redbird community.</div>

          {error && <div className="form-error">{error}</div>}
          {success && <div className="form-success">{success}</div>}

          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-input" name="name" value={form.name} onChange={handle} placeholder="John Doe" />
          </div>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input className="form-input" name="username" value={form.username} onChange={handle} placeholder="redbird123" />
          </div>
          <div className="form-group">
            <label className="form-label">ISU Email</label>
            <input className="form-input" name="email" type="email" value={form.email} onChange={handle} placeholder="jdoe@ilstu.edu" />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="••••••••" />
          </div>
          <div className="form-group">
            <label className="form-label">Year</label>
            <select className="form-select" name="year" value={form.year} onChange={handle}>
              <option value="">Select your year</option>
              <option value="Freshman">Freshman</option>
              <option value="Sophomore">Sophomore</option>
              <option value="Junior">Junior</option>
              <option value="Senior">Senior</option>
              <option value="Graduate">Graduate</option>
            </select>
          </div>

          <label className="settings-toggle" style={{ marginBottom: '1rem' }}>
            <input type="checkbox" checked={twoFactorEnabled} onChange={e => setTwoFactorEnabled(e.target.checked)} />
            <div>
              <div className="settings-toggle-label">Enable 2FA on this account</div>
              <div className="settings-toggle-desc">Adds a 6-digit code step to login.</div>
            </div>
          </label>

          {codeRequested && (
            <div className="form-group">
              <label className="form-label">Email Verification Code</label>
              <input
                className="form-input"
                value={verificationCode}
                onChange={e => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="Enter 6-digit code"
              />
            </div>
          )}

          {!codeRequested ? (
            <button className="form-btn" onClick={requestCode} disabled={loading}>
              {loading ? 'Sending code...' : 'Send Verification Code'}
            </button>
          ) : (
            <>
              <button className="form-btn" onClick={submit} disabled={loading}>
                {loading ? 'Creating account...' : 'Verify Code & Create Account'}
              </button>
              <button
                className="nav-btn"
                style={{ marginTop: '0.8rem' }}
                onClick={requestCode}
                disabled={loading}
              >
                Resend Code
              </button>
            </>
          )}

          <div className="form-footer">
            Already have an account?{' '}
            <button className="form-link" onClick={() => navigate('login')}>Sign in here</button>
          </div>
        </div>
      </div>
    </div>
  );
}
