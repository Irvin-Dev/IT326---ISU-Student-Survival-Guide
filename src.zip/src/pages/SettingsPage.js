import React, { useState } from 'react';

const API = 'http://localhost:8080';

export default function SettingsPage({ navigate, user, setUser, logout }) {
  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    username: user?.username || '',
    department: user?.department || '',
    year: user?.year || '',
    password: ''
  });
  const [anonymity, setAnonymity] = useState(!!user?.anonymity);
  const [notifications, setNotifications] = useState(user?.notifications !== false);

  const [savingProfile, setSavingProfile] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  if (!user) {
    return (
      <div>
        <nav className="nav">
          <div className="nav-logo">ISU <span>SURVIVAL</span></div>
          <div className="nav-links">
            <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
          </div>
        </nav>
        <div className="loading">Sign in to access settings.</div>
      </div>
    );
  }

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const buildQuery = (params) => {
    const parts = [];
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') parts.push(`${k}=${encodeURIComponent(v)}`);
    });
    return parts.join('&');
  };

  const saveProfile = async () => {
    setMsg(''); setErr('');
    setSavingProfile(true);
    try {
      const q = buildQuery({
        email: form.email,
        name: form.name,
        username: form.username,
        department: form.department,
        year: form.year,
        password: form.password
      });
      const res = await fetch(`${API}/account/${user.accountId}?${q}`, { method: 'PUT' });
      if (res.ok) {
        const updated = await res.json();
        setUser(updated);
        setForm({ ...form, password: '' });
        setMsg('Profile updated.');
      } else {
        setErr('Could not update profile.');
      }
    } catch {
      setErr('Could not connect to server.');
    }
    setSavingProfile(false);
  };

  const saveSettings = async (nextAnon, nextNotif) => {
    setMsg(''); setErr('');
    setSavingSettings(true);
    try {
      const q = buildQuery({ anonymity: nextAnon, notifications: nextNotif });
      const res = await fetch(`${API}/account/${user.accountId}/settings?${q}`, { method: 'PUT' });
      if (res.ok) {
        const updated = await res.json();
        setUser(updated);
        setMsg('Settings saved.');
      } else {
        setErr('Could not save settings.');
        // revert toggles
        setAnonymity(!!user.anonymity);
        setNotifications(user.notifications !== false);
      }
    } catch {
      setErr('Could not connect to server.');
    }
    setSavingSettings(false);
  };

  const onAnonymityChange = (val) => { setAnonymity(val); saveSettings(val, notifications); };
  const onNotificationsChange = (val) => { setNotifications(val); saveSettings(anonymity, val); };

  const deleteAccount = async () => {
    setMsg(''); setErr('');
    setDeleting(true);
    try {
      const res = await fetch(`${API}/account/${user.accountId}`, { method: 'DELETE' });
      if (res.ok) {
        logout();
      } else {
        setErr('Could not delete account.');
      }
    } catch {
      setErr('Could not connect to server.');
    }
    setDeleting(false);
  };

  return (
    <div>
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          <div className="nav-user">
            <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
            <span>{user.username}</span>
          </div>
          <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
        </div>
      </nav>

      <div className="course-hero">
        <div className="course-hero-inner">
          <h1>SETTINGS</h1>
          <div className="course-hero-meta">
            <span>Manage your account, preferences, and privacy.</span>
          </div>
        </div>
      </div>

      <div className="course-body">
        {msg && <div className="form-success">{msg}</div>}
        {err && <div className="form-error">{err}</div>}

        <div className="settings-card">
          <div className="settings-title">Profile</div>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-input" name="name" value={form.name} onChange={handle} />
          </div>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input className="form-input" name="username" value={form.username} onChange={handle} />
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input className="form-input" name="email" type="email" value={form.email} onChange={handle} />
          </div>
          <div className="form-group">
            <label className="form-label">Department</label>
            <input className="form-input" name="department" value={form.department} onChange={handle} />
          </div>
          <div className="form-group">
            <label className="form-label">Year</label>
            <select className="form-select" name="year" value={form.year} onChange={handle}>
              <option value="">Select your year</option>
              <option value="Freshman">Freshman</option>
              <option value="Sophomore">Sophomore</option>
              <option value="Junior">Junior</option>
              <option value="Senior">Senior</option>
              <option value="Graduate">Graduate</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">New Password (leave blank to keep current)</label>
            <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="••••••••" />
          </div>
          <button className="action-btn primary" onClick={saveProfile} disabled={savingProfile}>
            {savingProfile ? 'Saving...' : 'Save Profile'}
          </button>
        </div>

        <div className="settings-card">
          <div className="settings-title">Privacy & Notifications</div>
          <label className="settings-toggle">
            <input type="checkbox" checked={anonymity} onChange={e => onAnonymityChange(e.target.checked)} disabled={savingSettings} />
            <div>
              <div className="settings-toggle-label">Post anonymously</div>
              <div className="settings-toggle-desc">Your name will be hidden on comments and ratings.</div>
            </div>
          </label>
          <label className="settings-toggle">
            <input type="checkbox" checked={notifications} onChange={e => onNotificationsChange(e.target.checked)} disabled={savingSettings} />
            <div>
              <div className="settings-toggle-label">Email notifications</div>
              <div className="settings-toggle-desc">Email me when someone replies to my comments.</div>
            </div>
          </label>
        </div>

        <div className="settings-card danger-zone">
          <div className="settings-title">Danger Zone</div>
          <div className="settings-toggle-desc" style={{ marginBottom: '1rem' }}>
            Deleting your account is permanent and removes all of your associated data.
          </div>
          {!confirmDelete ? (
            <button className="action-btn danger" onClick={() => setConfirmDelete(true)}>Delete Account</button>
          ) : (
            <div style={{ display: 'flex', gap: '0.8rem', alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={{ fontWeight: 600 }}>Are you sure?</span>
              <button className="action-btn danger" onClick={deleteAccount} disabled={deleting}>
                {deleting ? 'Deleting...' : 'Yes, delete forever'}
              </button>
              <button className="action-btn" onClick={() => setConfirmDelete(false)}>Cancel</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
