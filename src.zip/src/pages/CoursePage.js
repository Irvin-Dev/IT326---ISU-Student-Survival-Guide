import React, { useState, useEffect, useMemo } from 'react';

const API = 'http://localhost:8080';

// ----- tiny presentational helpers ---------------------------------------

const StarPicker = ({ value, onChange, size = 22 }) => (
  <div style={{ display: 'inline-flex', gap: 4 }}>
    {[1, 2, 3, 4, 5].map(n => (
      <span
        key={n}
        onClick={() => onChange(value === n ? null : n)}
        style={{
          cursor: 'pointer',
          fontSize: size,
          color: n <= (value || 0) ? '#f5b301' : '#d4d4d4',
          userSelect: 'none',
          lineHeight: 1
        }}
      >★</span>
    ))}
  </div>
);

const StarDisplay = ({ value, size = 14 }) => (
  <span style={{ color: '#f5b301', fontSize: size, letterSpacing: 1 }}>
    {[1, 2, 3, 4, 5].map(n => (
      <span key={n} style={{ opacity: n <= value ? 1 : 0.25 }}>★</span>
    ))}
  </span>
);

const DifficultyBadge = ({ value }) => {
  if (value == null) return null;
  // 1 = breeze, 5 = brutal — color ramp from green to red.
  const colors = ['#2ecc71', '#a3d957', '#f5b301', '#f0793b', '#e74c3c'];
  const labels = ['Easy', 'Light', 'Moderate', 'Hard', 'Brutal'];
  const i = Math.max(1, Math.min(5, Math.round(value))) - 1;
  return (
    <span style={{
      background: colors[i] + '22',
      color: colors[i],
      border: `1px solid ${colors[i]}55`,
      padding: '2px 8px',
      borderRadius: 999,
      fontSize: 11,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: 0.5
    }}>
      Difficulty: {labels[i]}
    </span>
  );
};

const TagChip = ({ label, active, onClick, removable }) => (
  <span
    onClick={onClick}
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      background: active ? '#cf2030' : '#f1f1f3',
      color: active ? '#fff' : '#444',
      border: active ? '1px solid #cf2030' : '1px solid #e2e2e6',
      padding: '4px 10px',
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 500,
      cursor: onClick ? 'pointer' : 'default',
      userSelect: 'none'
    }}
  >
    {label}
    {removable && <span style={{ marginLeft: 2, opacity: 0.7 }}>×</span>}
  </span>
);

const RatingDistribution = ({ dist }) => {
  if (!dist) return null;
  const total = Object.values(dist).reduce((a, b) => a + b, 0);
  if (total === 0) {
    return <div style={{ color: '#999', fontSize: 13 }}>No ratings yet.</div>;
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxWidth: 360 }}>
      {[5, 4, 3, 2, 1].map(star => {
        const count = dist[star] || 0;
        const pct = total ? (count / total) * 100 : 0;
        return (
          <div key={star} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
            <span style={{ width: 14, color: '#666' }}>{star}</span>
            <span style={{ color: '#f5b301' }}>★</span>
            <div style={{ flex: 1, background: '#eee', borderRadius: 4, height: 10, overflow: 'hidden' }}>
              <div style={{ width: `${pct}%`, height: '100%', background: '#f5b301' }} />
            </div>
            <span style={{ width: 28, textAlign: 'right', color: '#666' }}>{count}</span>
          </div>
        );
      })}
    </div>
  );
};

// ----- main page ---------------------------------------------------------

export default function CoursePage({ navigate, user, selectedCourse, setSelectedCourse }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(null);
  const [newDifficulty, setNewDifficulty] = useState(null);
  const [newTagIds, setNewTagIds] = useState([]);

  const [availableTags, setAvailableTags] = useState([]);
  const [stats, setStats] = useState({ averageRating: null, averageDifficulty: null });
  const [distribution, setDistribution] = useState(null);
  const [sortBy, setSortBy] = useState('newest');

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [replyParentId, setReplyParentId] = useState(null);
  const [replyText, setReplyText] = useState('');

  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');

  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ courseName: '', courseCode: '', department: '' });
  const [editErr, setEditErr] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  const loadComments = () => {
    if (!selectedCourse) return;
    setLoading(true);
    const acct = user ? `&accountId=${user.accountId}` : '';
    const sortParam = sortBy === 'likes' ? '&sort=likes' : '';
    fetch(`${API}/comments/${selectedCourse.courseId}?_=1${acct}${sortParam}`)
      .then(r => r.json())
      .then(data => { setComments(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const loadStats = () => {
    if (!selectedCourse) return;
    fetch(`${API}/courses/${selectedCourse.courseId}/stats`)
      .then(r => r.json())
      .then(setStats)
      .catch(() => {});
    fetch(`${API}/courses/${selectedCourse.courseId}/rating-distribution`)
      .then(r => r.json())
      .then(setDistribution)
      .catch(() => {});
  };

  useEffect(() => {
    loadComments();
    loadStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCourse, sortBy, user]);

  useEffect(() => {
    fetch(`${API}/tags`)
      .then(r => r.json())
      .then(data => setAvailableTags(Array.isArray(data) ? data : []))
      .catch(() => {});
  }, []);

  // Group comments into tree: top-level + replies-by-parent-id.
  const { topLevel, repliesBy } = useMemo(() => {
    const top = [];
    const map = {};
    for (const c of comments) {
      if (c.parentCommentId == null) top.push(c);
      else {
        if (!map[c.parentCommentId]) map[c.parentCommentId] = [];
        map[c.parentCommentId].push(c);
      }
    }
    return { topLevel: top, repliesBy: map };
  }, [comments]);

  const toggleTag = (tagId) => {
    setNewTagIds(prev => prev.includes(tagId) ? prev.filter(t => t !== tagId) : [...prev, tagId]);
  };

  const submitComment = async () => {
    if (!newComment.trim() || !user) return;
    setSubmitting(true);
    try {
      const params = new URLSearchParams({
        comment: newComment,
        accountId: String(user.accountId),
        courseId: String(selectedCourse.courseId),
      });
      if (newRating != null) params.set('rating', String(newRating));
      if (newDifficulty != null) params.set('difficulty', String(newDifficulty));
      if (newTagIds.length > 0) params.set('tagIds', newTagIds.join(','));

      const res = await fetch(`${API}/comment/create?${params.toString()}`, { method: 'POST' });
      if (res.ok) {
        setNewComment('');
        setNewRating(null);
        setNewDifficulty(null);
        setNewTagIds([]);
        loadComments();
        loadStats();
      }
    } catch {}
    setSubmitting(false);
  };

  const submitReply = async (parentId) => {
    if (!replyText.trim() || !user) return;
    try {
      const params = new URLSearchParams({
        comment: replyText,
        accountId: String(user.accountId),
        courseId: String(selectedCourse.courseId),
        parentCommentId: String(parentId),
      });
      const res = await fetch(`${API}/comment/create?${params.toString()}`, { method: 'POST' });
      if (res.ok) {
        setReplyText('');
        setReplyParentId(null);
        loadComments();
      }
    } catch {}
  };

  const saveEditComment = async (commentId) => {
    if (!editText.trim() || !user) return;
    try {
      const res = await fetch(
        `${API}/comment/${commentId}?comment=${encodeURIComponent(editText)}&accountId=${user.accountId}`,
        { method: 'PUT' }
      );
      if (res.ok) {
        setEditingId(null);
        setEditText('');
        loadComments();
      }
    } catch {}
  };

  const deleteComment = async (commentId) => {
    if (!user) return;
    if (!window.confirm('Delete this comment? Replies will be deleted too.')) return;
    try {
      const res = await fetch(`${API}/comment/${commentId}?accountId=${user.accountId}`, { method: 'DELETE' });
      if (res.ok) { loadComments(); loadStats(); }
    } catch {}
  };

  // Optimistic toggle: flip locally, then call backend; revert on failure.
  const toggleLike = async (c) => {
    if (!user) { navigate('login'); return; }
    const willLike = !c.likedByMe;
    setComments(prev => prev.map(x =>
      x.commentId === c.commentId
        ? { ...x, likedByMe: willLike, likes: (x.likes || 0) + (willLike ? 1 : -1) }
        : x
    ));
    try {
      const res = await fetch(
        `${API}/comment/${c.commentId}/like?accountId=${user.accountId}`,
        { method: willLike ? 'POST' : 'DELETE' }
      );
      if (!res.ok) loadComments(); // revert by reloading
    } catch {
      loadComments();
    }
  };

  const startEdit = () => {
    setEditForm({
      courseName: selectedCourse.courseName || '',
      courseCode: String(selectedCourse.courseCode || ''),
      department: selectedCourse.department || ''
    });
    setEditErr('');
    setEditing(true);
  };

  const saveEdit = async () => {
    setEditErr('');
    const { courseName, courseCode, department } = editForm;
    if (!courseName || !courseCode || !department) { setEditErr('Please fill in all fields.'); return; }
    if (!/^\d+$/.test(courseCode)) { setEditErr('Course code must be a number.'); return; }
    setSavingEdit(true);
    try {
      const q = `courseName=${encodeURIComponent(courseName)}&courseCode=${courseCode}&department=${encodeURIComponent(department)}`;
      const res = await fetch(`${API}/courses/${selectedCourse.courseId}?${q}`, { method: 'PUT' });
      if (res.ok) {
        const updated = await res.json();
        setSelectedCourse(updated);
        setEditing(false);
      } else {
        setEditErr('Could not save changes.');
      }
    } catch {
      setEditErr('Could not connect to server.');
    }
    setSavingEdit(false);
  };

  if (!selectedCourse) {
    return <div className="loading">No course selected.</div>;
  }

  const fmtDate = ts => {
    if (!ts) return '';
    const d = new Date(ts);
    return isNaN(d.getTime()) ? '' : d.toLocaleString();
  };

  const renderComment = (c, depth = 0) => {
    const isOwner = user && user.accountId === c.accountId;
    const replies = repliesBy[c.commentId] || [];
    const isEditing = editingId === c.commentId;

    return (
      <div key={c.commentId} className="comment-thread" style={{ marginLeft: depth * 32 }}>
        <div className="comment-card">
          <div className="comment-header">
            <span className="comment-author">{c.authorUsername || 'Anonymous user'}</span>
            <span className="comment-meta">
              {fmtDate(c.createdAt)}
              {c.updatedAt && c.createdAt && c.updatedAt !== c.createdAt ? ' · edited' : ''}
            </span>
          </div>

          {/* Rating + difficulty + tags only on top-level reviews */}
          {depth === 0 && (c.rating || c.difficulty || (c.tags && c.tags.length > 0)) && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center', margin: '6px 0 10px' }}>
              {c.rating && <StarDisplay value={c.rating} />}
              <DifficultyBadge value={c.difficulty} />
              {c.tags && c.tags.map(t => (
                <TagChip key={t.tagId} label={t.keyword} />
              ))}
            </div>
          )}

          {isEditing ? (
            <>
              <textarea
                className="comment-textarea"
                value={editText}
                onChange={e => setEditText(e.target.value)}
              />
              <div className="comment-actions">
                <button className="action-btn primary" onClick={() => saveEditComment(c.commentId)}>Save</button>
                <button className="action-btn" onClick={() => { setEditingId(null); setEditText(''); }}>Cancel</button>
              </div>
            </>
          ) : (
            <>
              <div className="comment-body">{c.comment}</div>
              <div className="comment-actions" style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <button
                  className="comment-link"
                  onClick={() => toggleLike(c)}
                  style={{
                    color: c.likedByMe ? '#cf2030' : undefined,
                    fontWeight: c.likedByMe ? 600 : undefined
                  }}
                  title={user ? '' : 'Sign in to like'}
                >
                  {c.likedByMe ? '♥' : '♡'} {c.likes || 0}
                </button>
                {user && (
                  <>
                    <button className="comment-link" onClick={() => { setReplyParentId(c.commentId); setReplyText(''); }}>Reply</button>
                    {isOwner && (
                      <>
                        <button className="comment-link" onClick={() => { setEditingId(c.commentId); setEditText(c.comment); }}>Edit</button>
                        <button className="comment-link danger" onClick={() => deleteComment(c.commentId)}>Delete</button>
                      </>
                    )}
                  </>
                )}
              </div>
            </>
          )}

          {replyParentId === c.commentId && (
            <div className="reply-box">
              <textarea
                className="comment-textarea"
                placeholder="Write a reply..."
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
              />
              <div className="comment-actions">
                <button className="action-btn primary" onClick={() => submitReply(c.commentId)} disabled={!replyText.trim()}>Post Reply</button>
                <button className="action-btn" onClick={() => { setReplyParentId(null); setReplyText(''); }}>Cancel</button>
              </div>
            </div>
          )}
        </div>

        {replies.map(r => renderComment(r, depth + 1))}
      </div>
    );
  };

  const fmtNum = (v, suffix = '') => v == null ? '—' : `${Number(v).toFixed(1)}${suffix}`;

  return (
    <div className="course-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user ? (
            <>
              <button className="nav-btn" onClick={() => navigate('settings')}>Settings</button>
              <div className="nav-user">
                <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span>{user.username}</span>
              </div>
            </>
          ) : (
            <button className="nav-btn primary" onClick={() => navigate('login')}>Sign In</button>
          )}
        </div>
      </nav>

      <div className="course-hero">
        <div className="course-hero-inner">
          <button className="back-btn" onClick={() => navigate('main')}>← Back to courses</button>
          <h1>{selectedCourse.courseName}</h1>
          <div className="course-hero-meta">
            <span>{selectedCourse.department}</span>
            <span>Code: {selectedCourse.courseCode}</span>
          </div>
          {user && !editing && (
            <button className="action-btn" style={{ marginTop: '1rem' }} onClick={startEdit}>Edit Course</button>
          )}
        </div>
      </div>

      <div className="course-body">
        {editing && (
          <div className="settings-card">
            <div className="settings-title">Edit Course</div>
            {editErr && <div className="form-error">{editErr}</div>}
            <div className="form-group">
              <label className="form-label">Course Name</label>
              <input className="form-input" value={editForm.courseName}
                     onChange={e => setEditForm({ ...editForm, courseName: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Course Code</label>
              <input className="form-input" value={editForm.courseCode}
                     onChange={e => setEditForm({ ...editForm, courseCode: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Department</label>
              <input className="form-input" value={editForm.department}
                     onChange={e => setEditForm({ ...editForm, department: e.target.value })} />
            </div>
            <div style={{ display: 'flex', gap: '0.8rem' }}>
              <button className="action-btn primary" onClick={saveEdit} disabled={savingEdit}>
                {savingEdit ? 'Saving...' : 'Save Changes'}
              </button>
              <button className="action-btn" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          </div>
        )}

        <div className="ratings-row">
          <div className="rating-card">
            <div className="rating-val">{fmtNum(stats.averageRating)}</div>
            <div className="rating-lbl">Overall Rating</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">{fmtNum(stats.averageDifficulty)}</div>
            <div className="rating-lbl">Difficulty</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">{comments.length}</div>
            <div className="rating-lbl">Reviews</div>
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #eee', borderRadius: 12, padding: '1rem 1.2rem', marginBottom: '1.5rem' }}>
          <div style={{ fontSize: 13, color: '#666', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10, fontWeight: 600 }}>
            Rating breakdown
          </div>
          <RatingDistribution dist={distribution} />
        </div>

        <div className="section-label" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span>Reviews</span>
          <select
            className="filter-select"
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            style={{ marginLeft: 'auto' }}
          >
            <option value="newest">Newest first</option>
            <option value="likes">Most liked</option>
          </select>
        </div>

        {user ? (
          <div className="comment-card" style={{ marginBottom: '1.5rem' }}>
            <textarea
              className="comment-textarea"
              placeholder="Share your experience with this course..."
              value={newComment}
              onChange={e => setNewComment(e.target.value)}
            />
            <div style={{ display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap', margin: '10px 0' }}>
              <div>
                <div style={{ fontSize: 11, color: '#666', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4, fontWeight: 600 }}>Rating</div>
                <StarPicker value={newRating} onChange={setNewRating} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: '#666', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4, fontWeight: 600 }}>Difficulty</div>
                <div style={{ display: 'inline-flex', gap: 4 }}>
                  {[1, 2, 3, 4, 5].map(n => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setNewDifficulty(newDifficulty === n ? null : n)}
                      style={{
                        width: 28, height: 28,
                        border: '1px solid ' + (newDifficulty === n ? '#cf2030' : '#ddd'),
                        background: newDifficulty === n ? '#cf2030' : '#fff',
                        color: newDifficulty === n ? '#fff' : '#444',
                        borderRadius: 6,
                        cursor: 'pointer',
                        fontWeight: 600
                      }}
                    >{n}</button>
                  ))}
                </div>
              </div>
            </div>
            {availableTags.length > 0 && (
              <div style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 11, color: '#666', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6, fontWeight: 600 }}>Tags</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {availableTags.map(t => (
                    <TagChip
                      key={t.tagId}
                      label={t.keyword}
                      active={newTagIds.includes(t.tagId)}
                      onClick={() => toggleTag(t.tagId)}
                    />
                  ))}
                </div>
              </div>
            )}
            <div className="comment-actions">
              <button className="action-btn primary" onClick={submitComment} disabled={submitting || !newComment.trim()}>
                {submitting ? 'Posting...' : 'Post Review'}
              </button>
            </div>
          </div>
        ) : (
          <div style={{ background: '#fff8f8', border: '1px solid #ffd0d0', borderRadius: '12px', padding: '1.2rem', marginBottom: '1.5rem', fontSize: '0.9rem', color: '#888' }}>
            <button className="form-link" onClick={() => navigate('login')}>Sign in</button> to leave a review.
          </div>
        )}

        {loading ? (
          <div className="loading">Loading reviews...</div>
        ) : topLevel.length === 0 ? (
          <div className="empty">No reviews yet. Be the first!</div>
        ) : (
          topLevel.map(c => renderComment(c, 0))
        )}
      </div>
    </div>
  );
}
