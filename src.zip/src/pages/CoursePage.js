import React, { useState, useEffect } from 'react';

const API = 'http://localhost:8080';

export default function CoursePage({ navigate, user, selectedCourse }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!selectedCourse) return;
    fetch(`${API}/comments/${selectedCourse.courseId}`)
      .then(r => r.json())
      .then(data => { setComments(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [selectedCourse]);

  const submitComment = async () => {
    if (!newComment.trim() || !user) return;
    setSubmitting(true);
    try {
      const res = await fetch(
        `${API}/comment/create?comment=${encodeURIComponent(newComment)}&accountId=${user.accountID}&courseId=${selectedCourse.courseId}`,
        { method: 'POST' }
      );
      if (res.ok) {
        const c = await res.json();
        setComments([c, ...comments]);
        setNewComment('');
      }
    } catch {}
    setSubmitting(false);
  };

  if (!selectedCourse) {
    return <div className="loading">No course selected.</div>;
  }

  return (
    <div className="course-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user ? (
            <>
              <div className="nav-user">
                <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span>{user.username}</span>
              </div>
            </>
          ) : (
            <button className="nav-btn primary" onClick={() => navigate('login')}>Sign In</button>
          )}
        </div>
      </nav>

      <div className="course-hero">
        <div className="course-hero-inner">
          <button className="back-btn" onClick={() => navigate('main')}>← Back to courses</button>
          <h1>{selectedCourse.courseName}</h1>
          <div className="course-hero-meta">
            <span>{selectedCourse.department}</span>
            <span>Code: {selectedCourse.courseCode}</span>
          </div>
        </div>
      </div>

      <div className="course-body">
        <div className="ratings-row">
          <div className="rating-card">
            <div className="rating-val">—</div>
            <div className="rating-lbl">Overall Rating</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">—</div>
            <div className="rating-lbl">Difficulty</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">{comments.length}</div>
            <div className="rating-lbl">Reviews</div>
          </div>
        </div>

        <div className="section-label">Reviews</div>

        {user ? (
          <div style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 2px 20px rgba(0,0,0,0.08)' }}>
            <textarea
              style={{ width: '100%', padding: '0.8rem', border: '1.5px solid #e0e0dc', borderRadius: '8px', fontFamily: 'DM Sans, sans-serif', fontSize: '0.95rem', resize: 'vertical', minHeight: '100px', outline: 'none' }}
              placeholder="Share your experience with this course..."
              value={newComment}
              onChange={e => setNewComment(e.target.value)}
            />
            <button
              className="form-btn"
              style={{ width: 'auto', marginTop: '0.8rem', padding: '0.7rem 1.5rem' }}
              onClick={submitComment}
              disabled={submitting || !newComment.trim()}
            >
              {submitting ? 'Posting...' : 'Post Review'}
            </button>
          </div>
        ) : (
          <div style={{ background: '#fff8f8', border: '1px solid #ffd0d0', borderRadius: '12px', padding: '1.2rem', marginBottom: '1.5rem', fontSize: '0.9rem', color: '#888' }}>
            <button className="form-link" onClick={() => navigate('login')}>Sign in</button> to leave a review.
          </div>
        )}

        {loading ? (
          <div className="loading">Loading reviews...</div>
        ) : comments.length === 0 ? (
          <div className="empty">No reviews yet. Be the first!</div>
        ) : (
          comments.map((c, i) => (
            <div key={i} style={{ background: 'white', borderRadius: '12px', padding: '1.3rem 1.5rem', marginBottom: '1rem', boxShadow: '0 2px 20px rgba(0,0,0,0.06)', borderLeft: '3px solid #CE1126' }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 600, letterSpacing: '1px', textTransform: 'uppercase', color: '#6b6b6b', marginBottom: '0.5rem' }}>
                {c.account?.username || 'Anonymous'}
              </div>
              <div style={{ fontSize: '0.95rem', lineHeight: 1.6 }}>{c.comment}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
