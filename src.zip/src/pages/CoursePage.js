import React, { useState, useEffect, useMemo } from 'react';

const API = 'http://localhost:8080';

export default function CoursePage({ navigate, user, selectedCourse, setSelectedCourse }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [replyParentId, setReplyParentId] = useState(null);
  const [replyText, setReplyText] = useState('');

  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');

  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ courseName: '', courseCode: '', department: '' });
  const [editErr, setEditErr] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  const loadComments = () => {
    if (!selectedCourse) return;
    setLoading(true);
    fetch(`${API}/comments/${selectedCourse.courseId}`)
      .then(r => r.json())
      .then(data => { setComments(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(loadComments, [selectedCourse]);

  // Group comments into a tree: top-level + replies-by-parent-id
  const { topLevel, repliesBy } = useMemo(() => {
    const top = [];
    const map = {};
    for (const c of comments) {
      if (c.parentCommentId == null) top.push(c);
      else {
        if (!map[c.parentCommentId]) map[c.parentCommentId] = [];
        map[c.parentCommentId].push(c);
      }
    }
    return { topLevel: top, repliesBy: map };
  }, [comments]);

  const submitComment = async () => {
    if (!newComment.trim() || !user) return;
    setSubmitting(true);
    try {
      const res = await fetch(
        `${API}/comment/create?comment=${encodeURIComponent(newComment)}&accountId=${user.accountId}&courseId=${selectedCourse.courseId}`,
        { method: 'POST' }
      );
      if (res.ok) {
        setNewComment('');
        loadComments();
      }
    } catch {}
    setSubmitting(false);
  };

  const submitReply = async (parentId) => {
    if (!replyText.trim() || !user) return;
    try {
      const res = await fetch(
        `${API}/comment/create?comment=${encodeURIComponent(replyText)}&accountId=${user.accountId}&courseId=${selectedCourse.courseId}&parentCommentId=${parentId}`,
        { method: 'POST' }
      );
      if (res.ok) {
        setReplyText('');
        setReplyParentId(null);
        loadComments();
      }
    } catch {}
  };

  const saveEditComment = async (commentId) => {
    if (!editText.trim() || !user) return;
    try {
      const res = await fetch(
        `${API}/comment/${commentId}?comment=${encodeURIComponent(editText)}&accountId=${user.accountId}`,
        { method: 'PUT' }
      );
      if (res.ok) {
        setEditingId(null);
        setEditText('');
        loadComments();
      }
    } catch {}
  };

  const deleteComment = async (commentId) => {
    if (!user) return;
    if (!window.confirm('Delete this comment? Replies will be deleted too.')) return;
    try {
      const res = await fetch(`${API}/comment/${commentId}?accountId=${user.accountId}`, { method: 'DELETE' });
      if (res.ok) loadComments();
    } catch {}
  };

  const startEdit = () => {
    setEditForm({
      courseName: selectedCourse.courseName || '',
      courseCode: String(selectedCourse.courseCode || ''),
      department: selectedCourse.department || ''
    });
    setEditErr('');
    setEditing(true);
  };

  const saveEdit = async () => {
    setEditErr('');
    const { courseName, courseCode, department } = editForm;
    if (!courseName || !courseCode || !department) { setEditErr('Please fill in all fields.'); return; }
    if (!/^\d+$/.test(courseCode)) { setEditErr('Course code must be a number.'); return; }
    setSavingEdit(true);
    try {
      const q = `courseName=${encodeURIComponent(courseName)}&courseCode=${courseCode}&department=${encodeURIComponent(department)}`;
      const res = await fetch(`${API}/courses/${selectedCourse.courseId}?${q}`, { method: 'PUT' });
      if (res.ok) {
        const updated = await res.json();
        setSelectedCourse(updated);
        setEditing(false);
      } else {
        setEditErr('Could not save changes.');
      }
    } catch {
      setEditErr('Could not connect to server.');
    }
    setSavingEdit(false);
  };

  if (!selectedCourse) {
    return <div className="loading">No course selected.</div>;
  }

  const fmtDate = ts => {
    if (!ts) return '';
    const d = new Date(ts);
    return isNaN(d.getTime()) ? '' : d.toLocaleString();
  };

  const renderComment = (c, depth = 0) => {
    const isOwner = user && user.accountId === c.accountId;
    const replies = repliesBy[c.commentId] || [];
    const isEditing = editingId === c.commentId;

    return (
      <div key={c.commentId} className="comment-thread" style={{ marginLeft: depth * 32 }}>
        <div className="comment-card">
          <div className="comment-header">
            <span className="comment-author">{c.authorUsername || 'Anonymous user'}</span>
            <span className="comment-meta">
              {fmtDate(c.createdAt)}
              {c.updatedAt && c.createdAt && c.updatedAt !== c.createdAt ? ' · edited' : ''}
            </span>
          </div>

          {isEditing ? (
            <>
              <textarea
                className="comment-textarea"
                value={editText}
                onChange={e => setEditText(e.target.value)}
              />
              <div className="comment-actions">
                <button className="action-btn primary" onClick={() => saveEditComment(c.commentId)}>Save</button>
                <button className="action-btn" onClick={() => { setEditingId(null); setEditText(''); }}>Cancel</button>
              </div>
            </>
          ) : (
            <>
              <div className="comment-body">{c.comment}</div>
              {user && (
                <div className="comment-actions">
                  <button className="comment-link" onClick={() => { setReplyParentId(c.commentId); setReplyText(''); }}>Reply</button>
                  {isOwner && (
                    <>
                      <button className="comment-link" onClick={() => { setEditingId(c.commentId); setEditText(c.comment); }}>Edit</button>
                      <button className="comment-link danger" onClick={() => deleteComment(c.commentId)}>Delete</button>
                    </>
                  )}
                </div>
              )}
            </>
          )}

          {replyParentId === c.commentId && (
            <div className="reply-box">
              <textarea
                className="comment-textarea"
                placeholder="Write a reply..."
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
              />
              <div className="comment-actions">
                <button className="action-btn primary" onClick={() => submitReply(c.commentId)} disabled={!replyText.trim()}>Post Reply</button>
                <button className="action-btn" onClick={() => { setReplyParentId(null); setReplyText(''); }}>Cancel</button>
              </div>
            </div>
          )}
        </div>

        {replies.map(r => renderComment(r, depth + 1))}
      </div>
    );
  };

  return (
    <div className="course-page">
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user ? (
            <>
              <button className="nav-btn" onClick={() => navigate('settings')}>Settings</button>
              <div className="nav-user">
                <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span>{user.username}</span>
              </div>
            </>
          ) : (
            <button className="nav-btn primary" onClick={() => navigate('login')}>Sign In</button>
          )}
        </div>
      </nav>

      <div className="course-hero">
        <div className="course-hero-inner">
          <button className="back-btn" onClick={() => navigate('main')}>← Back to courses</button>
          <h1>{selectedCourse.courseName}</h1>
          <div className="course-hero-meta">
            <span>{selectedCourse.department}</span>
            <span>Code: {selectedCourse.courseCode}</span>
          </div>
          {user && !editing && (
            <button className="action-btn" style={{ marginTop: '1rem' }} onClick={startEdit}>Edit Course</button>
          )}
        </div>
      </div>

      <div className="course-body">
        {editing && (
          <div className="settings-card">
            <div className="settings-title">Edit Course</div>
            {editErr && <div className="form-error">{editErr}</div>}
            <div className="form-group">
              <label className="form-label">Course Name</label>
              <input className="form-input" value={editForm.courseName}
                     onChange={e => setEditForm({ ...editForm, courseName: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Course Code</label>
              <input className="form-input" value={editForm.courseCode}
                     onChange={e => setEditForm({ ...editForm, courseCode: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Department</label>
              <input className="form-input" value={editForm.department}
                     onChange={e => setEditForm({ ...editForm, department: e.target.value })} />
            </div>
            <div style={{ display: 'flex', gap: '0.8rem' }}>
              <button className="action-btn primary" onClick={saveEdit} disabled={savingEdit}>
                {savingEdit ? 'Saving...' : 'Save Changes'}
              </button>
              <button className="action-btn" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          </div>
        )}

        <div className="ratings-row">
          <div className="rating-card">
            <div className="rating-val">—</div>
            <div className="rating-lbl">Overall Rating</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">—</div>
            <div className="rating-lbl">Difficulty</div>
          </div>
          <div className="rating-card">
            <div className="rating-val">{comments.length}</div>
            <div className="rating-lbl">Reviews</div>
          </div>
        </div>

        <div className="section-label">Reviews</div>

        {user ? (
          <div className="comment-card" style={{ marginBottom: '1.5rem' }}>
            <textarea
              className="comment-textarea"
              placeholder="Share your experience with this course..."
              value={newComment}
              onChange={e => setNewComment(e.target.value)}
            />
            <div className="comment-actions">
              <button className="action-btn primary" onClick={submitComment} disabled={submitting || !newComment.trim()}>
                {submitting ? 'Posting...' : 'Post Review'}
              </button>
            </div>
          </div>
        ) : (
          <div style={{ background: '#fff8f8', border: '1px solid #ffd0d0', borderRadius: '12px', padding: '1.2rem', marginBottom: '1.5rem', fontSize: '0.9rem', color: '#888' }}>
            <button className="form-link" onClick={() => navigate('login')}>Sign in</button> to leave a review.
          </div>
        )}

        {loading ? (
          <div className="loading">Loading reviews...</div>
        ) : topLevel.length === 0 ? (
          <div className="empty">No reviews yet. Be the first!</div>
        ) : (
          topLevel.map(c => renderComment(c, 0))
        )}
      </div>
    </div>
  );
}
