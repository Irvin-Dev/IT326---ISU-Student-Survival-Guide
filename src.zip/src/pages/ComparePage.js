import React from 'react';

export default function ComparePage({ navigate, user, compareSet }) {
  if (!compareSet || compareSet.length !== 2) {
    return (
      <div>
        <nav className="nav">
          <div className="nav-logo">ISU <span>SURVIVAL</span></div>
          <div className="nav-links">
            <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
          </div>
        </nav>
        <div className="loading">No courses selected for comparison.</div>
      </div>
    );
  }

  const [a, b] = compareSet;

  const row = (label, va, vb) => (
    <div className="compare-row">
      <div className="compare-row-label">{label}</div>
      <div className="compare-row-val">{va ?? '—'}</div>
      <div className="compare-row-val">{vb ?? '—'}</div>
    </div>
  );

  const tagsString = (c) =>
    c.courseTagList && c.courseTagList.length > 0
      ? c.courseTagList.map(t => t.keyword).join(', ')
      : '—';

  return (
    <div>
      <nav className="nav">
        <div className="nav-logo">ISU <span>SURVIVAL</span></div>
        <div className="nav-links">
          {user && (
            <div className="nav-user">
              <div className="nav-avatar">{user.name?.[0]?.toUpperCase()}</div>
              <span>{user.username}</span>
            </div>
          )}
          <button className="nav-btn" onClick={() => navigate('main')}>← Back</button>
        </div>
      </nav>

      <div className="course-hero">
        <div className="course-hero-inner">
          <h1>COMPARE COURSES</h1>
          <div className="course-hero-meta">
            <span>{a.courseName} vs. {b.courseName}</span>
          </div>
        </div>
      </div>

      <div className="course-body">
        <div className="compare-table">
          <div className="compare-row compare-header">
            <div className="compare-row-label"></div>
            <div className="compare-row-val">
              <div className="compare-course-name">{a.courseName}</div>
              <div className="compare-course-code">{a.department} · CODE {a.courseCode}</div>
            </div>
            <div className="compare-row-val">
              <div className="compare-course-name">{b.courseName}</div>
              <div className="compare-course-code">{b.department} · CODE {b.courseCode}</div>
            </div>
          </div>
          {row('Department', a.department, b.department)}
          {row('Course Code', a.courseCode, b.courseCode)}
          {row('Course Level', `${Math.floor((a.courseCode || 0) / 100) * 100}-level`, `${Math.floor((b.courseCode || 0) / 100) * 100}-level`)}
          {row('Tags', tagsString(a), tagsString(b))}
        </div>

        <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
          <button className="action-btn" onClick={() => navigate('course', a)}>View {a.courseName}</button>
          <button className="action-btn" onClick={() => navigate('course', b)}>View {b.courseName}</button>
        </div>
      </div>
    </div>
  );
}
