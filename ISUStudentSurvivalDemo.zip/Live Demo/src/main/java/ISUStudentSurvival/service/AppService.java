package ISUStudentSurvival.service;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.repository.AccountRepository;
import ISUStudentSurvival.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private AccountRepository accountRepository;

    public Course createCourse(String courseName, int courseCode, String department) {
        Course course = new Course(courseName, courseCode, department);
        return courseRepository.save(course);
    }

    public Account createAccount(String email, String password, String name, String year, String username) {
        Account account = new Account(email, password, name, year, username);
        return accountRepository.save(account);
    }
}