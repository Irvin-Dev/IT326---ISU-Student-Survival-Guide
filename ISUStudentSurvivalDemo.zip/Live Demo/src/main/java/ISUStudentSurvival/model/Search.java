package ISUStudentSurvival.model;

import java.util.ArrayList;

interface Search {
    ArrayList<Course> search(String query);
}
