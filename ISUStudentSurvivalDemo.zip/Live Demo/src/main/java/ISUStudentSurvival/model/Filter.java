package ISUStudentSurvival.model;

import java.util.ArrayList;

interface Filter {
    ArrayList<Course> filterByLevel(int level);

    ArrayList<Course> sortByRating();

    ArrayList<Course> sortByDifficulty();
}
