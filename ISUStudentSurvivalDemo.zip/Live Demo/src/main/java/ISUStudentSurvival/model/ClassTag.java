package ISUStudentSurvival.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class ClassTag
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tagId;
    private String keyword;

    @ManyToOne
    private Course course;

    public ClassTag() {}

    public ClassTag(String keyword, Course course)
    {
        this.keyword = keyword;
        this.course = course;
    }

    public int getTagId()
    {
        return tagId;
    }

    public String getKeyword()
    {
        return keyword;
    }

    public Course getCourse()
    {
        return course;
    }

    public void setKeyword(String keyword)
    {
        this.keyword = keyword;
    }

    public String toString()
    {
        return "Class Tag(s): " + keyword;
    }
}