package ISUStudentSurvival.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "COURSE")
public class Course
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COURSEID")
    private int courseId;

    @Column(name = "COURSENAME")
    private String courseName;

    @Column(name = "COURSECODE")
    private int courseCode;

    @Column(name = "DEPARTMENT")
    private String department;

    public Course() {}

    public Course(String courseName, Integer courseCode, String department)
    {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.department = department;
    }

    public String getCourseName()
    {
        return courseName;
    }

    public int getCourseId()
    {
        return courseId;
    }

    public int getCourseCode()
    {
        return courseCode;
    }

    public String getDepartment()
    {
        return department;
    }

    public void setCourseName(String courseName)
    {
        this.courseName = courseName;
    }

    public void setCourseId(Integer courseId)
    {
        this.courseId = courseId;
    }

    public void setCourseCode(Integer courseCode)
    {
        this.courseCode = courseCode;
    }

    public void setDepartment(String department)
    {
        this.department = department;
    }

    public String toString()
    {
        return "||Course||\n" + "Course Name: " + courseName + "\nCourse ID: " + courseId + "\nCourse Code: " + courseCode + "\nDepartment: " + department;
    }

    public void updateTagList()
    {
    }

    public void updateRatings()
    {
    }

    public void generateCourseDistribution()
    {
    }
}