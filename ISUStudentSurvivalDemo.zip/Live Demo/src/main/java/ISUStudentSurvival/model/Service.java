package ISUStudentSurvival.model;

public class Service {
}
