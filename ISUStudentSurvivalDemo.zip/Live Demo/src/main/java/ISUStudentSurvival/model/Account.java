package ISUStudentSurvival.model;

import jakarta.persistence.*;

@SuppressWarnings("ALL")
@Entity
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int accountID;
    private String email;
    private String password;
    private String name;
    private String year;
    private String username;

    @Embedded
    private AccountSettings settings;

    public Account() {}

    public Account(String email, String password, String name, String year, String username) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.year = year;
        this.username = username;
    }

    public int getAccountID() {
        return accountID;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getYear() {
        return year;
    }

    public String getUsername() {
        return username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void changeUsername(String newUsername) {
        this.username = newUsername;
    }

    public void changePassword(String newPassword) {
        this.password = newPassword;
    }

    public AccountSettings getSettings() {
        return settings;
    }
}