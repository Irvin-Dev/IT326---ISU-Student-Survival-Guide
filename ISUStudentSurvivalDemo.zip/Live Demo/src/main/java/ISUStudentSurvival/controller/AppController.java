package ISUStudentSurvival.controller;

import ISUStudentSurvival.model.Account;
import ISUStudentSurvival.model.Course;
import ISUStudentSurvival.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {

    @Autowired
    private AppService appService;

    @PostMapping("/course/create")
    public Course createCourse(@RequestParam String courseName,
                               @RequestParam int courseCode,
                               @RequestParam String department) {
        return appService.createCourse(courseName, courseCode, department);
    }

    @PostMapping("/account/create")
    public Account createAccount(@RequestParam String email,
                                 @RequestParam String password,
                                 @RequestParam String name,
                                 @RequestParam String year,
                                 @RequestParam String username) {
        return appService.createAccount(email, password, name, year, username);
    }
}